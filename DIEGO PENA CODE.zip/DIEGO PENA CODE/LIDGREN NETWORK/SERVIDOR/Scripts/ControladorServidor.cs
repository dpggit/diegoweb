using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ControladorServidor : MonoBehaviour {
	
	// astar
	private Vector3 puntocaminoB=Vector3.zero;
	private int velocidadMov=500;
	private int puntoProgreso;
	public List<cAstar> ret;
	private cAstar destino;
	public float pixMovidos=0;


	private float tiempot=0;
	public int movimiento=20;
	public bool enMovimiento;
	public float[,] arrCols;

    string msgalerta;
	
		

	void Start () {
	}

	void Update () {

	comprobarRuta();
	
	}
	
	
	void comprobarRuta()
	{
		if(puntocaminoB!=Vector3.zero)
		{
			enMovimiento=true;
			float valorh=(new Vector2(puntocaminoB.x,puntocaminoB.z)-new Vector2(transform.position.x,transform.position.z)).magnitude;
			
			if(puntoProgreso>0)
			{
				if(valorh==0)
				{
					if(tiempot>0)
					{
						float tiempot2=Time.realtimeSinceStartup;
						float tiempototal=tiempot2-tiempot;
						tiempot=0;
					}
					
					puntoProgreso--;
					
					puntocaminoB=ret[puntoProgreso].post;
				}
			}
			else 
			{
				puntocaminoB=destino.post;
				if(valorh==0)
				{
					if(tiempot>0)
					{
						float tiempot2=Time.realtimeSinceStartup;
						float tiempototal=tiempot2-tiempot;
						tiempot=0;
					}
					transform.position=destino.post;
					puntocaminoB=Vector3.zero;
					//enMovimiento=false;
				}
			}
			if(puntocaminoB!=Vector3.zero)
			{
				transform.position=Vector3.MoveTowards(transform.position,new Vector3(puntocaminoB.x,transform.position.y,puntocaminoB.z),Time.deltaTime*velocidadMov);
			}
		}
        else enMovimiento = false;
	}
	
/*	
		
	public void astar(Vector3 posdestino)
	{
        pixMovidos = 0;
		int r=-1;
		ushort limiteSaltos=5000;
		ushort alturaRay=1000;
		float separacion;
		int lowInd;
		bool gScoreIsBest;
		float gScore;
		bool nlista=false;
		List<cAstar> openList = new List<cAstar>();
		List<cAstar> closedList = new List<cAstar>();
		ret = new List<cAstar>();
		cAstar curr=new cAstar(Vector3.zero);
		cAstar currentNode=new cAstar(Vector3.zero);
		bool siguiente=false;
		Vector3 n0post=Vector3.zero;
		Vector3 n1post=Vector3.zero;
		Vector3 n2post=Vector3.zero;
		Vector3 n3post=Vector3.zero;
		Vector3 n5post=Vector3.zero;
		Vector3 n6post=Vector3.zero;
		Vector3 n7post=Vector3.zero;
		Vector3 n8post=Vector3.zero;
		float tiempoInicio=Time.realtimeSinceStartup;
		float tiempoFin;
		float ratioDiagonal=(movimiento*movimiento+movimiento*movimiento);
		int ratioNormal=movimiento*movimiento;

		int indicex=(int)Mathf.Floor(transform.position.x/movimiento);
		int indicez=(int)Mathf.Floor(transform.position.z/movimiento);
		RaycastHit hit2;
		puntocaminoB=Vector3.zero;
		pixMovidos=0;
		int saltos=0;

		destino=new cAstar(posdestino);
		float valorh=(destino.post-transform.position).sqrMagnitude;
		cAstar start=new cAstar(transform.position);
		start.padre=null;
		start.h=valorh;
		start.f=valorh;
		start.g=0;
	
		openList.Add(start);
		
		destino.g=0;
		destino.padre=null;
		destino.f=valorh;
		destino.h=0;
		
		while(openList.Count>0)
		{
			saltos++;
			if(saltos>limiteSaltos) 
			{
				r=-2;
				break;
			}
			lowInd = 0;

			for(int i=0;i<openList.Count;i++)
			{
				if(openList[i].f<openList[lowInd].f) { lowInd = i; }
			}

			currentNode=openList[lowInd];

			if(currentNode.h<=ratioDiagonal)
			{
				curr = currentNode;
				while(curr.padre!=null)
				{
					pixMovidos+=curr.g;
					ret.Add(curr);
					curr = curr.padre;
				}
				r=ret.Count-1;
				break;
			}
			else
			{

				if(openList.Contains(currentNode)) openList.Remove(currentNode);

				closedList.Add(currentNode);
				indicex=(int)Mathf.Floor(currentNode.x/movimiento);
				indicez=(int)Mathf.Floor(currentNode.z/movimiento);
				List<cAstar> neighbors = new List<cAstar>();
				n0post=Vector3.zero;
				n1post=Vector3.zero;
				n2post=Vector3.zero;
				n3post=Vector3.zero;
				n5post=Vector3.zero;
				n6post=Vector3.zero;
				n7post=Vector3.zero;
				n8post=Vector3.zero;
				
				if(transform.position.y>arrCols[indicex-1,indicez+1])
				{
					n0post=currentNode.post+new Vector3(-movimiento,0,movimiento);
					neighbors.Add(new cAstar(n0post));
					neighbors[neighbors.Count-1].d=true;
				}
				if(transform.position.y>arrCols[indicex,indicez+1])
				{
					n1post=currentNode.post+new Vector3(0,0,movimiento);
					neighbors.Add(new cAstar(n1post));
				}
				if(transform.position.y>arrCols[indicex+1,indicez+1])
				{
					n2post=currentNode.post+new Vector3(movimiento,0,movimiento);
					neighbors.Add(new cAstar(n2post));
					neighbors[neighbors.Count-1].d=true;
				}
				if(transform.position.y>arrCols[indicex-1,indicez])
				{
					n3post=currentNode.post+new Vector3(-movimiento,0,0);
					neighbors.Add(new cAstar(n3post));
				}
				if(transform.position.y>arrCols[indicex+1,indicez])
				{
					n5post=currentNode.post+new Vector3(movimiento,0,0);
					neighbors.Add(new cAstar(n5post));
				}
				if(transform.position.y>arrCols[indicex-1,indicez-1])
				{
					n6post=currentNode.post+new Vector3(-movimiento,0,-movimiento);
					neighbors.Add(new cAstar(n6post));
					neighbors[neighbors.Count-1].d=true;
				}
				if(transform.position.y>arrCols[indicex,indicez-1])
				{
					n7post=currentNode.post+new Vector3(0,0,-movimiento);
					neighbors.Add(new cAstar(n7post));
				}
				if(transform.position.y>arrCols[indicex+1,indicez-1])
				{
					n8post=currentNode.post+new Vector3(movimiento,0,-movimiento);
					neighbors.Add(new cAstar(n8post));
					neighbors[neighbors.Count-1].d=true;
				}

				if(neighbors.Count>0)
				{
					for(int k=0;k<neighbors.Count;k++)
					{			
						siguiente=false;
						//if(closedList.Contains(neighbors[k])) continue;
						
						for(int i=0;i<closedList.Count;i++)
						{
							if(neighbors[k].x==closedList[i].x && neighbors[k].z==closedList[i].z) 
							//if(neighbors[k]==closedList[i]) 
							{
								siguiente=true;
								break ;
							}
						}
						
						if(siguiente) continue;
				
						if(neighbors[k].d) gScore = (float)(currentNode.g + ratioDiagonal);
						else gScore = currentNode.g + movimiento; 
						nlista=false;
						
						for(int i=0;i<openList.Count;i++)
						{
							if(neighbors[k].x==openList[i].x && neighbors[k].z==openList[i].z) nlista=true;
							//if(neighbors[k]==openList[i]) nlista=true;
						}
						
						if(!nlista) 
						//if(!openList.Contains(neighbors[k]))
						{
							openList.Add(neighbors[k]);
							neighbors[k].h = (destino.post-neighbors[k].post).sqrMagnitude;
							neighbors[k].padre = currentNode;
							neighbors[k].g = gScore;
							neighbors[k].f = neighbors[k].g+neighbors[k].h;
						}
					} 
				}
				else 
				{
					r=-2;
					break;
				}
			}
		} 
		
		if(r>=0)
		{
			puntoProgreso=ret.Count-1;
			puntocaminoB=ret[ret.Count-1].post;
			tiempoFin=Time.realtimeSinceStartup;
			float tiempo=tiempoFin-tiempoInicio;
			msgalerta+="Tiempo : "+tiempo.ToString()+" Saltos :"+openList.Count.ToString();

		}
		else if(r==-1)
		{
			puntoProgreso=-1;
			puntocaminoB=destino.post;
		}	
		tiempot=Time.realtimeSinceStartup;
	}
*/	
 
    public void astar(Vector3 posdestino)
    {
        int lowInd;
        bool gScoreIsBest;
        float gScore;
        List<cMAstar> openList = new List<cMAstar>();
        List<cMAstar> closedList = new List<cMAstar>();
        List<cMAstar> neighbors = new List<cMAstar>();
        ret = new List<cMAstar>();
        cMAstar curr=new cMAstar(Vector3.zero);
        cMAstar currentNode=new cMAstar(Vector3.zero);
        int saltos=0;
        int nNeigh=0;
        List<cMAstar> listaStart = new List<cMAstar>();
        List<float> listaStartF = new List<float>();
        Vector3 vinicio=Vector3.zero;
        //Inicio proceso
        dirDown = transform.TransformDirection(Vector3.down);
        tiempot=Time.realtimeSinceStartup;
        puntocaminoB = Vector3.zero;
        cMAstar start = new cMAstar(Vector3.zero);
	
        if(Physics.Raycast (posdestino, dirDown, out hit,10f, layerMaskSuelo))
        {
            posdestino=hit.point;
        }
	
        List<cMAstar> arrAstar = Program.arrAstar;
        float valorh=0;
        if(Physics.Raycast (transform.position+maxAlturaVector, dirDown, out hit,100f,layerMaskSuelo))
        {
            vinicio=hit.point;
            for(int i=0;i<arrAstar.Count;i++)
            {
                arrAstar[i].padre = null;
                arrAstar[i].bloqueado=false;
                arrAstar[i].g=0;
                arrAstar[i].h=0;
                arrAstar[i].f=0;
                arrAstar[i].closed=false;
                arrAstar[i].open=false;
                if((arrAstar[i].post-vinicio).sqrMagnitude<distanciaMinNodos)
                {		
                    if(Physics.Raycast (arrAstar[i].post+maxAlturaVector, dirDown, out hit,100f))
                    {
                        if(hit.collider.gameObject==gameObject || hit.collider.gameObject.layer==12)
                        {
                            listaStart.Add(arrAstar[i]);
                            listaStartF.Add((arrAstar[i].post-vinicio).sqrMagnitude);
                        }
                    }
                }
            }
        }
        if(listaStartF.Count==0) return;
        listaStartF.Sort();
        valorh = listaStartF[0];
        for(int i=0;i<listaStart.Count;i++)
        {
            if(Mathf.Approximately(valorh,(listaStart[i].post-vinicio).sqrMagnitude))
            {
                start = listaStart[i];
                valorh = listaStartF[0];
                break;
            }
        }	
        start.h=valorh;
        start.f=valorh;
        openList.Add(start);

        while(openList.Count!=0)
        {
            lowInd = 0;
            for(int i=0;i<openList.Count;i++)
            {
                if(openList[i].f<openList[lowInd].f) 
                {
                    if((openList[i].post-openList[lowInd].post).sqrMagnitude<=(distanciaMinNodos))
                    {
                        lowInd = i; 
                    }
                }
            }
            currentNode=openList[lowInd];

            if((posdestino-currentNode.post).sqrMagnitude<distanciaMin)
            {
                curr = currentNode;

                while(curr.padre!=null)
                {
                    ret.Add(curr);
                    curr = curr.padre;
                }
                r=ret.Count-1;
                tiempoFin=Time.realtimeSinceStartup;
                float tiempo=tiempoFin-tiempoInicio;
                break;
            }
            else
            {
                openList.Remove(currentNode);
                closedList.Add(currentNode);
                currentNode.closed=true;

                for(int i=0;i<currentNode.vecinos.Count;i++)
                {
                    if(currentNode.vecinos[i].closed) continue;
                    currentNode.vecinos[i].closed=true;
                    float distneig = (currentNode.post-currentNode.vecinos[i].post).sqrMagnitude;
                    gScore = (float)(currentNode.g + distneig);
                    if(!currentNode.vecinos[i].open || gScore < currentNode.vecinos[i].g)
                    {
                        currentNode.vecinos[i].h = (posdestino-currentNode.vecinos[i].post).sqrMagnitude;
                        currentNode.vecinos[i].padre = currentNode;
                        currentNode.vecinos[i].g = gScore;
                        currentNode.vecinos[i].f = currentNode.vecinos[i].g+currentNode.vecinos[i].h;
                        currentNode.vecinos[i].open=true;
                        openList.Add(currentNode.vecinos[i]);
                    }
                    nNeigh++;
                }
            }
        } 
	
        if(r>=0)
        {
		/*
            for(int i=0;i<ret.Count;i++)
            {
                GameObject ocubo = Instantiate(cubo,ret[i].post+new Vector3(0,1.5f,0),Quaternion.identity) as GameObject;
                float tam = 1f;
                ocubo.transform.localScale = new Vector3(tam,3f,tam);
                listaCubos.Add(ocubo);
            }
            */
		
        }
        else if(r==-1)
        {
            r=-2;
            puntocaminoB=Vector3.zero;
            return;
        }	
    }

    void tiempoTotal(string msg)
	{
		float tiempot2=Time.realtimeSinceStartup;
		float total=tiempot2-tiempot;
	}

    void OnGUI()
    {
        GUI.Label(new Rect(10, 100, 700, 700), "Mensaje=" + msgalerta);
    }

}




public class cAstar 
{
	public Vector3 post;
	public float x;
	public float z;
	public cAstar padre;
	public float g;
	public float h;
	public float f;
	public bool d;
	
	public cAstar(Vector3 post)
	{
		this.post=post;
		this.x=post.x;
		this.z=post.z;
		this.padre=null;
		this.g=0;
		this.h=0;
		this.f=0;
		this.d=false;
	}
}