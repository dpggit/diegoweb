using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class manager2 : MonoBehaviour {
	
	public GameObject personaje;
	public static float colaMov=0;
	public static float intervaloAstar=1f;
	public static List<cMAstar> arrAstar;
	public static float radio;
	public static float movimiento = 0.8f;
	public static float diagonal = 1.2f;
	public static bool ocupado = false;
	public static List<GameObject> cola = new List<GameObject>();
	public static int indiceCam=0;
	public static GameObject[] camaras; 
	public GameObject camara;
	
	RaycastHit hit;
	RaycastHit hit2;
	public GameObject cubo;
	Vector3 dirDown=Vector3.zero;
	bool desCola=false;
	Vector3 maxAlturaVector;
	int layerMaskSuelo = 1 << 12;
	int layerMaskNoVallas;
	int layerMaskObjetivo = 1 << 8;
	GameObject[] muros;
	float siguienteIntervalo;
	
	
	void Start () {
		maxAlturaVector = new Vector3(0,1.5f,0);
		camaras = GameObject.FindGameObjectsWithTag("MainCamera"); 
		radio = 0.1f;
		layerMaskNoVallas = ~(layerMaskObjetivo | layerMaskSuelo);
		escanear();
	}
	
	IEnumerator iAstar()
	{
		cola[0].GetComponent<AStar>().fAstar();
		cola.Remove(cola[0]);
		yield return new WaitForSeconds(0.1f);
	}
	
	void Update () 
	{
		while(cola.Count>0) 
		{
			cola[0].GetComponent<AstarC>().fAstar();
			cola.Remove(cola[0]);
		}
	
		if(Time.time > siguienteIntervalo)
		{		
			colaMov=0;
       		siguienteIntervalo = Time.time + intervaloAstar;
    	}
		
		if(Input.GetMouseButtonDown(0))
		{
			Ray ray = camara.camera.ScreenPointToRay(Input.mousePosition);
			if (Physics.Raycast (ray, out hit)) 
			{
				if(hit.collider.gameObject.layer==9)
				{
					hit.collider.gameObject.GetComponent<AstarC>().seleccionado = true;
				}
			}
		}
		
		if(Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();
		}
		
		if(Input.GetKeyDown(KeyCode.T))
		{
			indiceCam++;
			if(indiceCam==camaras.Length) indiceCam=0;
			for(int i=0;i<camaras.Length;i++)
			{
				if(i==indiceCam) camaras[i].camera.enabled=true;
				else camaras[i].camera.enabled=false;
			}
		}
		
	}
	
	/*
	void OnGUI () 
	{
		
		GUI.Label (new Rect (10, 150, 700, 700), "Mensaje="+msgalerta);

		GUI.color= new Color(50f,10f,10f,1f);

		Event e = Event.current;

			GUI.Window (1, new Rect (Screen.width/2f-anchoInventario, Screen.height-anchoBox, anchoBox, altoBox), DoMyWindow, "1");
			GUI.Window (2, new Rect (Screen.width/2f-anchoInventario+anchoBox, Screen.height-anchoBox, anchoBox, altoBox), DoMyWindow, "2");
			GUI.Window (3, new Rect (Screen.width/2f-anchoInventario+anchoBox*2f, Screen.height-anchoBox, anchoBox, altoBox), DoMyWindow, "3");
			GUI.Window (4, new Rect (Screen.width/2f-anchoInventario+anchoBox*3f, Screen.height-anchoBox, anchoBox, altoBox), DoMyWindow, "4");
			GUI.Window (5, new Rect (Screen.width/2f-anchoInventario+anchoBox*4f, Screen.height-anchoBox, anchoBox, altoBox), DoMyWindow, "5");
		
		GUI.color=Color.red;
		//GUI.HorizontalScrollbar (new Rect (Screen.width*0.9f-anchobar/2f, Screen.height-30f, anchobar, 30f), vida, vida, 1.0f, 100.0f);
	
	}
	
	void DoMyWindow(int windowID) 
	{
		if(windowID==1)
		{
			GUI.DrawTexture(new Rect(anchoBox*0.02f,altoBox*0.3f,anchoBox-anchoBox*0.04f,altoBox-altoBox*0.35f), texturaBombaBasica, ScaleMode.ScaleToFit, true, 0);
		}
		else if(windowID==2)
		{
			GUI.DrawTexture(new Rect(anchoBox*0.02f,altoBox*0.3f,anchoBox-anchoBox*0.04f,altoBox-altoBox*0.35f), texturaBombaHumo, ScaleMode.ScaleToFit, true, 0);
		}
		else if(windowID==3)
		{
			GUI.DrawTexture(new Rect(anchoBox*0.02f,altoBox*0.3f,anchoBox-anchoBox*0.04f,altoBox-altoBox*0.35f), texturaBombaFuego, ScaleMode.ScaleToFit, true, 0);
		}
		
	}
	*/
	
	void escanear()
	{
		arrAstar = new List<cMAstar>();

		float inix = 50f;
		float finx = 150f;
		float iniz = 50f;
		float finz = 150f;
		
		RaycastHit[] hits;
		float distanciaMin = (movimiento*diagonal)*(movimiento*diagonal)+(1.5f*1.5f);
		float altura = personaje.transform.position.y+100f;
		for(float x=inix;x<finx;x+=movimiento)
		{
			for(float z=iniz;z<finz;z+=movimiento)
			{
				hits = Physics.RaycastAll(new Vector3(x,altura,z), Vector3.down, 110f, layerMaskSuelo);
				for(int k=0;k<hits.Length;k++)
				{
					if(k>0)
					{
						if(Mathf.Abs(hits[k].point.y-hits[k-1].point.y)>1f)
						{
							if(!Physics.CheckSphere(hits[k].point+maxAlturaVector,radio,layerMaskNoVallas))
							{
								arrAstar.Add(new cMAstar(hits[k].point));
							}
						}
					}
					else 
					{
						if(!Physics.CheckSphere(hits[k].point,radio,layerMaskNoVallas))
						{
							arrAstar.Add(new cMAstar(hits[k].point));
						}
					}
				}
			}
		}
		for(int i=0;i<arrAstar.Count;i++)
		{
			for(int j=0;j<arrAstar.Count;j++)
			{
				if((arrAstar[j].post-arrAstar[i].post).sqrMagnitude<=distanciaMin) 
				{
					if(arrAstar[j].post!=arrAstar[i].post)
					{
						if(Physics.Linecast(arrAstar[i].post+maxAlturaVector,arrAstar[j].post+maxAlturaVector, layerMaskNoVallas)) continue;
						Vector3 direccion = arrAstar[j].post-arrAstar[i].post;
						arrAstar[j].agregado = true;
						if(Physics.SphereCast (arrAstar[i].post+maxAlturaVector, radio*0.8f, direccion, out hit2,direccion.magnitude, layerMaskNoVallas)) continue;
						arrAstar[i].vecinos.Add(arrAstar[j]);
					}
				}
			}
		}
	}
}


public class cMAstar 
{
	public Vector3 post;
	public List<cMAstar> vecinos;
	public cMAstar padre;
	public bool bloqueado;
	public float g;
	public float h;
	public float f;
	public bool closed;
	public bool open;
	public bool agregado;
	
	public cMAstar(Vector3 post)
	{
		this.post=post;
		this.vecinos=new List<cMAstar>();
		this.padre = null;
		this.bloqueado=false;
		this.g=0;
		this.h=0;
		this.f=0;
		this.closed=false;
		this.open=false;
		this.agregado=false;
	}
}
