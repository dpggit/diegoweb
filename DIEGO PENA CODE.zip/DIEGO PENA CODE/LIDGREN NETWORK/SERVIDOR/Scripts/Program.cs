﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Lidgren.Network;
using Npgsql;


enum PacketTypes
{
    Beat,
    AssignId,
    Ready,
    UpdateName,
    PlayerAttemptedStart,
    PlayIntro,
    StartGame,
    AddPlayer,
    RemovePlayer,
    Movimiento,
    PlayerSpecial,
    HurtTarget,
    EnemyHealth,
    SelfHit,
    PlayerHit,
    EnemyPhaseChange,
    EnemyAction,
    EnemyTargetPosition,
    EnemyStartTargeting,
    EnemyEndTargeting,
    Message,
    SettingsChange,
    PlayerCount,
    Disconnect,
    LobbyMessage,
    EnemySync,
	Conectado,
	Login,
    Tiempo
}

class PObject
{
	public static PObject Instance;
    public static GameObject Container;
	
    public NetConnection Connection;
	public ControladorServidor Controller;
    public Int32 Id;
    public float X;
	public float Y;
    public float Z;
    public string Name;
	public string Textura;
    public string imgsuperior;
	public string imgcolorbase;
    public string imgcolorsuperior;
    public Int16 raza;
    public Int16 imagentipo;
	public List<PObject> Players;
	public float LastBeat=0;
    public float LastBeatMov = 0;
	public GameObject Obj;
	
    //public PObject(Int32 id, NetConnection connection, string name, string textura, GameObject obj, int curBeat, float[,] arrAstar)
    public PObject(Int32 id, NetConnection connection, string name, string textura, GameObject obj, float curBeat)
    {
        Connection = connection;
        Id = id;
        Name = name;
		Textura = textura;
		Obj = obj;
		LastBeat = curBeat;
        LastBeatMov = curBeat;
		Controller = Obj.GetComponent<ControladorServidor>();
    }
}


class Program : MonoBehaviour 
{
	bool servidorOn = false;
	private string msgalerta;
	Vector3 posdestino;
    private static NetServer server;
    private static NetPeerConfiguration config;
    public static List<PObject> players;
	private Int16 beatnum = 0;
	private int playercount = 0;
    public static int healthMod;
	//private DateTime time;
//	private DateTime LastBeat;
//	private TimeSpan beatrate;
	//private TimeSpan timetopass;
	NetIncomingMessage inc;
    private NetOutgoingMessage outmsg;
	private PObject Jugador;
	
	private int movimiento = 20;
	private int vx;
	private int vz;
	private RaycastHit hit;
	public static List<cMAstar> arrAstar;	
	
	WWW pagina;
	
	string url = "http://localhost/newageofmagicunity/paginas/unity.php";

    int segundos = 0;
    private float ultimoTiempo;
	// Cada hora cambia de dia a noche y viceversa
	int maxsegundos = 7200;
	int maxsegcambio = 3600;
	float tiempoInactividadMov=300f;
	bool dia=true;
	float puntosmovimiento = 0;

	//POSTGRESQL
	//NpgsqlConnection dbConnection;
	
	void Start()
    {
		StartCoroutine(gethora());
		msgalerta="Server rdy";
	}
	
	void Update()
	{
		if(servidorOn)
		{
			conexionesSalientes();
			conexionesEntrantes();
		}
	}

	void conectarServidor()
	{
		const string AllPolicy =
		@"<?xml version='1.0'?>
		<cross-domain-policy>
		    <allow-access-from domain=""*"" to-ports=""*"" />
		</cross-domain-policy>";
        SocketPolicyServer policyServer = new SocketPolicyServer(AllPolicy);
        int ret = policyServer.Start();
        config = new NetPeerConfiguration("newageofmagic");
        config.Port = 14248;
        config.MaximumConnections = 1000;
		// Si el servidor detecta que el cliente no responde en x segundos se cambia a status disconnected
		config.ConnectionTimeout = 15f;
		config.EnableMessageType(NetIncomingMessageType.ConnectionApproval);
		config.EnableMessageType(NetIncomingMessageType.Data);
		config.EnableMessageType(NetIncomingMessageType.StatusChanged);
        server = new NetServer(config);
        server.Start();
		players = new List<PObject>(); 
		ultimoTiempo = Time.time;
		servidorOn = true;
		msgalerta+="SEGUNDOS:"+segundos;
	}
	
	void OnGUI()
	{
		GUI.Label (new Rect (10, 20, 700, 700), "Mensaje="+msgalerta);
	}
	
	void OnApplicationQuit()
    {
		StartCoroutine(hora(true));
    }
	
	// Para hacer una desconexion manual
	void desconectar(PObject player)
	{
        outmsg = server.CreateMessage();
        outmsg.Write((byte)PacketTypes.Disconnect);
        server.SendMessage(outmsg, player.Connection, NetDeliveryMethod.ReliableOrdered);
		player.Connection.Disconnect("Timeout");
	}
	
	void conexionesSalientes()
	{
        float timeNow = Time.time;
        if (timeNow > (ultimoTiempo + 10f))
        {
            ultimoTiempo = timeNow;
            segundos += 10;
			if(segundos>=maxsegundos) segundos=0;
			
            outmsg = server.CreateMessage();
            outmsg.Write((byte)PacketTypes.Tiempo);
            outmsg.Write((Int16)segundos);
            server.SendToAll(outmsg, NetDeliveryMethod.ReliableOrdered);
			StartCoroutine(hora(false));
        }
		
		for (int i = 0; i < players.Count; i++)
    	{
            PObject player = players[i];
			if (player.LastBeatMov==0) continue;
			if ( player.LastBeatMov+tiempoInactividadMov < timeNow) desconectar(player);
			else
			{
				if(player.Controller.enMovimiento)
				{
					outmsg = server.CreateMessage();
                    outmsg.Write((byte)PacketTypes.Movimiento);
                    outmsg.Write((Int32)player.Id);
                    float x = player.Obj.transform.position.x;
                    float y = player.Obj.transform.position.y;
                    float z = player.Obj.transform.position.z;
                    outmsg.Write(x);
					outmsg.Write(y);
                    outmsg.Write(z);
					outmsg.Write(player.Connection.AverageRoundtripTime/2f);
                    server.SendMessage(outmsg, server.Connections, NetDeliveryMethod.ReliableOrdered, 1);
					if(posdestino.x==x && posdestino.y==y && posdestino.z==z)
					{
						player.Controller.enMovimiento = false;
                    	StartCoroutine(guardarDatos(player));
					}
				}
			 }
		 }
	}

	void conexionesEntrantes()
	{
		if ((inc = server.ReadMessage()) != null)
		{
	        switch(inc.MessageType)
	        {
	            case NetIncomingMessageType.ConnectionApproval:
					try
					{
						List<NetConnection> listaDuplicados = server.Connections.FindAll(p => p.Tag == inc.SenderConnection.Tag);
                        if (listaDuplicados.Count > 0) inc.SenderConnection.Deny("Acceso denegado");
                        else inc.SenderConnection.Approve();
					}
					catch (NetException) 
					{ 
						inc.SenderConnection.Deny("Acceso denegado");
					}
	                break;
		       case NetIncomingMessageType.Data:
					// No habra ningun jugador creado ya que tiene que llegar un data.login primero para crear el jugador
                    PObject player = players.Find(p => p.Connection.Tag == inc.SenderConnection.Tag);
					PacketTypes tipo = (PacketTypes)inc.ReadByte();
					msgalerta += "DATA :"+tipo.ToString();
					if (player == null && tipo!=PacketTypes.Login) break;
	                switch (tipo)
	                {
	                    case PacketTypes.Movimiento:
	                    {
					        float ratonX = inc.ReadFloat();
			                float alturaPer = inc.ReadFloat();
			                float ratonZ = inc.ReadFloat();
							RaycastHit hitInfo;
				            if (Physics.Raycast(new Vector3(ratonX,1000,ratonZ),Vector3.down,out hitInfo))
				            {
								if(alturaPer-6>hitInfo.point.y)
								{
									if(hitInfo.collider.gameObject.tag=="terreno" || 
										hitInfo.collider.gameObject.tag=="monstruos") 
										{
											posdestino = new Vector3(ratonX,alturaPer,ratonZ);
                                            player.LastBeatMov = Time.time;
											player.Controller.enMovimiento = false;
											player.Controller.astar(posdestino);
										}
								}
				            }
	                    }
	                    break;
                        case PacketTypes.Disconnect:
                        {
							desconectar(player);
                        }
                        break;
						case PacketTypes.Login:
	                    {
                            StartCoroutine(cargarWeb(inc));
                        }
						break;
				  } 
				break;
		        case NetIncomingMessageType.StatusChanged:
                {
					switch(inc.SenderConnection.Status)
					{
                        //primero se aprueba y luego se conecta
						case NetConnectionStatus.Connected:
							msgalerta += " SE CONECTA ";
                            outmsg = server.CreateMessage();
                            outmsg.Write((byte)PacketTypes.Login);
        					server.SendMessage(outmsg, inc.SenderConnection, NetDeliveryMethod.ReliableOrdered);
                        break;
						// Cambia a status disconnected cuando hay un timeout y se desconecta automaticamente o 
						// cuando hay una desconexion manual
						case NetConnectionStatus.Disconnected:
							player = players.Find(p => p.Connection.Tag == inc.SenderConnection.Tag);
							Destroy(player.Obj);
							players.Remove(player);
						break;
					}
                }
                break;
				default:
	            break;
	        } 
		}
	}
	
	
	void escanear()
	{
		for(int x=10;x<19990;x+=movimiento)
		{
			for(int z=10;z<19990;z+=movimiento)
			{
				if(Physics.Raycast (new Vector3(x,1000,z), new Vector3(0,-1,0), out hit))
				{
					arrAstar.Add(new cMAstar(hit.point));
				}
			}
		}
	}
	
	
	
	/*
	void escanear()
	{
		vx=0;
		vz=0;
		int xx=-1;
		int zz=-1;
		
		for(int x=10;x<19990;x+=movimiento)
		{
			vx++;
			vz=0;
			for(int z=10;z<19990;z+=movimiento)
			{
				vz++;	
			}
		}
		arrAstar=new float[vx,vz];

		for(int x=10;x<19990;x+=movimiento)
		{
			xx++;
			zz=-1;
			for(int z=10;z<19990;z+=movimiento)
			{
				zz++;	
				if(Physics.Raycast (new Vector3(x,1000,z), new Vector3(0,-1,0), out hit))
				{
					arrAstar[xx,zz]=hit.point.y;
				}
				else
				{
					arrAstar[xx,zz]=0;
				}
			}
		}
	}
	*/
	/*
		void escanear()
	{
		arrAstar = new List<cMAstar>();

		//radio = 0.1f;
		
		float inix = 50f;
		float finx = 200f;
		float iniz = 100f;
		float finz = 250f;

		
		RaycastHit[] hits;
		float distanciaMin = (movimiento*diagonal)*(movimiento*diagonal)+(1.5f*1.5f);
		float altura = personaje.transform.position.y+100f;
		for(float x=inix;x<finx;x+=movimiento)
		{
			for(float z=iniz;z<finz;z+=movimiento)
			{
				hits = Physics.RaycastAll(new Vector3(x,altura,z), Vector3.down, 110f, layerMaskSuelo);
				for(int k=0;k<hits.Length;k++)
				{
					if(k>0)
					{
						if(Mathf.Abs(hits[k].point.y-hits[k-1].point.y)>1f)
						{
							if(!Physics.CheckSphere(hits[k].point+maxAlturaVector,radio,layerMaskNoVallas))
							{
								arrAstar.Add(new cMAstar(hits[k].point));
							}
						}
					}
					else 
					{
						if(!Physics.CheckSphere(hits[k].point,radio,layerMaskNoVallas))
						{
							arrAstar.Add(new cMAstar(hits[k].point));
						}
					}
				}
			}
		}
		for(int i=0;i<arrAstar.Count;i++)
		{
			for(int j=0;j<arrAstar.Count;j++)
			{
				if((arrAstar[j].post-arrAstar[i].post).sqrMagnitude<=distanciaMin) 
				{
					if(arrAstar[j].post!=arrAstar[i].post)
					{
						if(Physics.Linecast(arrAstar[i].post+maxAlturaVector,arrAstar[j].post+maxAlturaVector, layerMaskNoVallas)) continue;
						Vector3 direccion = arrAstar[j].post-arrAstar[i].post;
						arrAstar[j].agregado = true;
						if(Physics.SphereCast (arrAstar[i].post+maxAlturaVector, radio*0.8f, direccion, out hit2,direccion.magnitude, layerMaskNoVallas)) continue;
						arrAstar[i].vecinos.Add(arrAstar[j]);
					}
				}
			}
		}
	
		for(int i=0;i<arrAstar.Count;i++)
		{

		}
	
	}
	*/
	
	
  	IEnumerator guardarDatos(PObject jugador)
    {
        WWWForm form = new WWWForm();
		msgalerta+="PIXMOVIDOS:"+jugador.Controller.pixMovidos;
		puntosmovimiento-=jugador.Controller.pixMovidos;
        form.AddField("actualizarpos", "si");
        form.AddField("idusuario", jugador.Id.ToString());
		form.AddField("pixmovidos", Mathf.FloorToInt(puntosmovimiento).ToString());
        form.AddField("x", jugador.Obj.transform.position.x.ToString());
        form.AddField("y", jugador.Obj.transform.position.y.ToString());
        form.AddField("z", jugador.Obj.transform.position.z.ToString());
        float tiempo1 = Time.time;
        WWW paginaact = new WWW(url,form);
        yield return paginaact;
    }
	
	IEnumerator hora(bool cerrar)
    {
		WWWForm form = new WWWForm();
		form.AddField("hora", "true");
	    form.AddField("valorhora", segundos);
        pagina = new WWW(url,form);
		yield return pagina;
		if(cerrar) server.Shutdown("cerrando");
	}
	
    IEnumerator gethora()
    {
        WWWForm form = new WWWForm();
        form.AddField("gethora", "true");
        pagina = new WWW(url, form);
        yield return pagina;
		if(pagina.text!="error")
		{
			segundos = Int16.Parse(pagina.text);
	        escanear();
	        conectarServidor();
		}
    }
	 
    IEnumerator cargarWeb(NetIncomingMessage inc2)
    {
		WWWForm form = new WWWForm();
		form.AddField("login", "true");
		string usuario = inc2.ReadString();
		string pass = inc2.ReadString();
	    form.AddField("user", usuario);
	    form.AddField("pass", pass);
        pagina = new WWW(url,form);
		yield return pagina;

		if(pagina.text=="error" || pagina.error!=null)
		{
			
		}
		else
		{
            string nombreper = "";
            Int16 raza=0;
            string imgsuperior = "";
            string imgcolorbase = "";
            string imgcolorsuperior = "";
            Int16 imagentipo=0;
            Int32 valorUnico = 0;
            float xx = 0, yy = 0, zz = 0;
            string[] info = pagina.text.Split(";"[0]);
            for (int x = 0; x < info.Length; x++)
            {
                string[] valorbd = info[x].Split(":"[0]);
                if (valorbd[0] == "nombreper") nombreper = (string)(valorbd[1]);
                if (valorbd[0] == "idusu") valorUnico = Int32.Parse(valorbd[1]);
                if (valorbd[0] == "raza") raza = Int16.Parse(valorbd[1]);
                if (valorbd[0] == "xx") xx = float.Parse(valorbd[1]);
                if (valorbd[0] == "yy") yy = float.Parse(valorbd[1]);
                if (valorbd[0] == "zz") zz = float.Parse(valorbd[1]);
                if (valorbd[0] == "imgsuperior") imgsuperior = (string)(valorbd[1]);
                if (valorbd[0] == "imgcolorbase") imgcolorbase = (string)(valorbd[1]);
                if (valorbd[0] == "imgcolorsuperior") imgcolorsuperior = (string)(valorbd[1]);
                if (valorbd[0] == "imagentipo") imagentipo = Int16.Parse(valorbd[1]);
				if (valorbd[0] == "puntosaccionesper") puntosmovimiento = Int16.Parse(valorbd[1]);
            }

            if (nombreper != "")
            {
                outmsg = server.CreateMessage();
                outmsg.Write((byte)PacketTypes.AssignId);
                outmsg.Write((Int32)valorUnico);
                server.SendMessage(outmsg, inc2.SenderConnection, NetDeliveryMethod.ReliableOrdered);
                GameObject cubo = GameObject.CreatePrimitive(PrimitiveType.Cube);
                cubo.transform.localScale = new Vector3(30f, 1f, 30f);
                cubo.AddComponent(typeof(ControladorServidor));
                GameObject objcubo = GameObject.Instantiate(cubo, new Vector3(xx, yy, zz), Quaternion.identity) as GameObject;
                PObject Jugador = new PObject(valorUnico, inc2.SenderConnection, nombreper, "personaje1", objcubo, Time.time);
                Jugador.imgsuperior = imgsuperior;
                Jugador.imgcolorbase = imgcolorbase;
                Jugador.imgcolorsuperior = imgcolorsuperior;
                Jugador.raza = raza;
                Jugador.imagentipo = imagentipo;
                players.Add(Jugador);
                for (int i = 0; i < players.Count; i++)
                {
                    outmsg = server.CreateMessage();
                    outmsg.Write((byte)PacketTypes.AddPlayer);
                    outmsg.Write((Int32)players[i].Id);
                    outmsg.Write(players[i].Obj.transform.position.x);
                    outmsg.Write(players[i].Obj.transform.position.y);
                    outmsg.Write(players[i].Obj.transform.position.z);
                    outmsg.Write(players[i].Name);
                    outmsg.Write(players[i].Textura);
                    outmsg.Write(players[i].imgsuperior);
                    outmsg.Write(players[i].imgcolorbase);
                    outmsg.Write(players[i].imgcolorsuperior);
                    outmsg.Write(players[i].raza);
                    outmsg.Write(players[i].imagentipo);
					outmsg.Write(segundos);
                    server.SendToAll(outmsg, NetDeliveryMethod.ReliableOrdered);
                }
				msgalerta+="NOMBREUSUARIO "+nombreper;
            }

		}
    }
	
}


        /*
		string connectionString =

          "Server=127.0.0.1;" +

          "Database=newageofmagic;" +

          "User ID=manowar;" +

          "Password=kkvaka30;";
		
		dbConnection = new NpgsqlConnection(connectionString);
        //dbConnection = new NpgsqlConnection("Server=127.0.0.1;Port=5432;User Id=manowar;Password=kkvaka30;Database=newageofmagic;");
        dbConnection.Open();
         */


/*
                                string usuario = inc.ReadString();
            string pass = inc.ReadString();
            msgalerta+="USUARIO"+usuario;
            */

/*
string usuario = inc.ReadString();
string pass = inc.ReadString();
userpass = usuario + "@" + pass;
msgalerta+="kkk"+userpass;
*/

/*
string sql = "SELECT nombremail FROM usuarios WHERE idusu=1";
//string sql = "SELECT p.nombreper,u.nombremail FROM usuarios u INNER JOIN  personajes p ON p.idusu=u.idusu " +
  //  "WHERE u.nombre='"+usuario+"' AND u.contra='"+pass+"'"         
NpgsqlCommand Command = new NpgsqlCommand(sql, dbConnection);
					
NpgsqlDataReader result = Command.ExecuteReader();
while (result.Read())
{
    mail = result.GetString(result.GetOrdinal("p.nombremail"));
    nombreper = result.GetString(result.GetOrdinal("u.nombreper"));
}
*/

/*
NpgsqlCommand dbcmd = dbConnection.CreateCommand();
								
//string sql = "SELECT p.nombreper,u.nombremail FROM usuarios u INNER JOIN  personajes p ON p.idusu=u.idusu " +
 //   "WHERE u.nombre='"+usuario+"' AND u.contra='"+pass+"'";
string sql = "SELECT nombremail FROM usuarios WHERE idusu=1";
dbcmd.CommandText = sql;						
NpgsqlDataReader reader = dbcmd.ExecuteReader();
						
while(reader.Read()) {
     mail = (string) reader["nombremail"];
}
								
reader.Close();
reader = null;
dbcmd.Dispose();
dbcmd = null;
*/


