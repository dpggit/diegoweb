using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using Lidgren.Network;
using System.Threading;


public class PlayerObject
{
    public Int32 Id;
    public GameObject Obj;
    public PlayerController Controller;
	
    public PlayerObject(Int32 id, GameObject obj, GameObject nombre)
	{
        Id = id;
        Obj = obj;
        Controller = Obj.GetComponent<PlayerController>();
		Controller.nombre = nombre;
    }
}



public class personaje : MonoBehaviour 
{
	
	public GameObject[] prefabPer;
	public GameObject prefabTextMesh;
	
	public GameObject camara;
	public GameObject sol;
	
	public Texture2D imgbase;
	public Texture2D[] listaImgPerSup;
	public Texture2D[] listaImgPer;
	
	Texture2D imgsuperior;
	public Texture cursor;

	
	public static string usuario;
	public static string pass;
	
	
	
	private Quaternion puntoAsol=Quaternion.Euler (0, 90, 250);
//	private Quaternion puntoBsol=Quaternion.Euler (70, 0, 180);
	private Quaternion puntoBsol=Quaternion.Euler (0, -90, 100);
	
	private Quaternion Asol=Quaternion.Euler (0, 90, 250);
	private Quaternion Bsol=Quaternion.Euler (0, -90, 100);
	
	private Quaternion siguientePuntoSol;
	public float maxintesidadSol=1.35f;
	public float minintesidadSol=0.2f;
	private float intensidadSol;
	private float intervaloSol=0;
	private string msgalerta;

	private bool activar=false;
	private bool menu=false;
	private Rect posper;
	
	// Ataques
	private string idmonstruo="";
	private string datosmonstruo;
	
	//onGUI
	public static int areaWidth=100;
	public static int areaHeight=50;
	public static float ScreenX;
	public static float ScreenY;
	
	// Caracteristicas BD
	private string datosusuario;
	private string nombreper;
	private int valorxarea;
	private int valoryarea;
	public static int perper=20;
	
	// Tiempo
	private float ultimoTiempo;
	private bool dia=true;
	// Cada 6 horas reales son 24 horas de juego, ratio 1:4, la noche empieza cada tres horas
	// los ciclos impares son dia, usando Ceil 1-3 dia, 4-6 noche pej 2/3=ceil(0.66)=1 dia, 4/3=ceil(1.33)=2
	private ushort horas;
	private ushort minutos;
	private Int16 segundos=0;
	//private float segundosDia;
	private float ratioTiempo=3;
	// 3 horas
	//private float ratioSegundos=10800;
	// Cada 3600 segundos pasa de dia a noche y al reves
	private float ratioSegundos=3600;
	
	// Datos enemigos
	private string datosenemigos;
	
	//actualizacion
	private int updateInterval = 2;

	//conexion
	private bool conectado=false;	
    public static GameObject Container;
	
    private static NetClient client;
    private NetIncomingMessage inc;
	 
    float roundtriptime = 0f;

    public static Int32 ClientId = -1;
    public PlayerObject Player;
    public static List<PlayerObject> Players;

    int numPlayers = 0;
	float lastBeat = 0f;
	bool isConnected = false;
	List<string> console;
	
		// astar
	private int velocidadMov=500;
	private Vector3 puntocaminoB=Vector3.zero;
	private int puntoProgreso;
	private List<cAstar> ret;
	private cAstar destino;
	private float pixMovidos=0;
	private RaycastHit hit;
	private float[,] arrCols;
	private int vx;
	private int vz;
	
	public int movimiento=40;
	
	
	GameObject planoinicio;
	static GameObject mensajeinicio;
	string userpass;
	public static bool escucharRed = false;
	Vector3 posDestino;
	//bool cargando=false;
	float mitadw;
	float mitadh;
	string imgcolorbase;
	string imgcolorsuperior;
	
	//public string[] valoreshumano;
	public List<cRazas> razas;
	
	
	enum PacketTypes
    {
        Beat,
        AssignId,
        Ready,
        UpdateName,
        PlayerAttemptedStart,
        PlayIntro,
        StartGame,
        AddPlayer,
        RemovePlayer,
        Movimiento,
        PlayerSpecial,
        HurtTarget,
        EnemyHealth,
        SelfHit,
        PlayerHit,
        EnemyPhaseChange,
        EnemyAction,
        EnemyTargetPosition,
        EnemyStartTargeting,
        EnemyEndTargeting,
        Message,
        SettingsChange,
        PlayerCount,
        Disconnect,
        LobbyMessage,
        EnemySync,
		Conectado,
		Login,
		Tiempo
    }
	


	void Awake () {
		
		//Application.ExternalCall("xajax_datosUsuario","");
	}
	
	/*
	IEnumerator esperar()
	{
		
		planoinicio = GameObject.Instantiate(Resources.Load("PlanoInicio"), new Vector3(0,799f,0), Quaternion.identity) as GameObject;
		mensajeinicio = GameObject.Instantiate(Resources.Load("NombrePersonaje"), new Vector3(0.5f,0.5f,0), Quaternion.identity) as GameObject;
		mensajeinicio.guiText.fontSize=30;
		mensajeinicio.guiText.text="Cargando...";
		
		yield return new WaitForSeconds(1);
		
		Destroy (mensajeinicio);
		Destroy (planoinicio);
		
		gameObject.GetComponent<GUITestScript>().doWindowPresentacion= true;
		//gameObject.GetComponent<GUITestScript>().doWindowMenu = true;
	}
	*/
	
	void Start () {
		// fuerza,destreza,agilidad,constitucion,influencia,sabiduria,inteligencia
		// armas cortas, armas largas, arco y ballesta, armas exoticas, esconderse,comerciar
		// RM, RFue, RFrio, RE, RVen
		razas = new List<cRazas>();
		string descrip = "Reciben una penalización de un -10 en combate en oscuridad o nocturno";
		razas.Add(new cRazas("Humanos",descrip,new int[7]{0,0,0,0,2,1,0},new int[7]{1,1,1,1,1,1,1},new int[7]{20,20,20,20,20,20,20},5,new int[7]{5,0,0,0,0,0,0},new int[5]{0,0,0,0,0},10));
		descrip = "Sin penalización en combate en oscuridad o nocturno";
		razas.Add(new cRazas("Elfos",descrip,new int[7]{-4,2,1,-4,0,2,1},new int[7]{5,1,10,5,5,10,10},new int[7]{15,25,25,15,20,25,30},5,new int[7]{0,-10,15,-10,10,-15,-15},new int[5]{5,0,0,0,15},5));
		descrip = "Reciben una penalización de un -5 en combate en oscuridad o nocturno";
		razas.Add(new cRazas("Enanos",descrip,new int[7]{-1,2,-4,2,-2,1,0},new int[7]{2,5,5,10,3,1,1},new int[7]{20,30,15,30,15,15,15},5,new int[7]{15,-10,-10,-5,0,-5,0},new int[5]{5,15,10,0,10},5));
		
		mitadw = Screen.width/2f;
		mitadh = Screen.height/2f;
		gameObject.GetComponent<GUITestScript>().doWindowLogin=true; 
		ScreenX = (float)((Screen.width * 0.5) - (areaWidth * 0.5));
		ScreenY = (float)((Screen.height * 0.5) - (areaHeight * 0.5));
		siguientePuntoSol=Quaternion.Lerp (puntoAsol, puntoBsol, intervaloSol);
		sol.transform.rotation=Quaternion.Lerp (puntoAsol, puntoBsol, intervaloSol);
	}
	
	public static void login()
	{
		mensajeinicio = GameObject.Instantiate(Resources.Load("NombrePersonaje"), new Vector3(0.5f,0.5f,0), Quaternion.identity) as GameObject;
		mensajeinicio.guiText.fontSize=30;
		mensajeinicio.guiText.text="Cargando...";
		Players = new List<PlayerObject>();
	    NetPeerConfiguration config = new NetPeerConfiguration("newageofmagic");
        client = new NetClient(config);
		NetOutgoingMessage outmsg = client.CreateMessage();
        client.Start();
        client.Connect("127.0.0.1", 14248, outmsg);
		escucharRed = true;
	}
	
	void recibirNetwork()
	{
	 	if (client.Status == NetPeerStatus.Running && (inc = client.ReadMessage()) != null)
        {
            switch (inc.MessageType)
            {
                case NetIncomingMessageType.Data:
                    {
                        switch (inc.ReadByte())
                        {
                            case (byte)PacketTypes.AssignId:
                                {
									Destroy (mensajeinicio);
                                    ClientId = inc.ReadInt32();
                                    isConnected = true;
									lastBeat = Time.time;
                                }
                                break;
                            case (byte)PacketTypes.AddPlayer:
                                {
                                    Int32 playerid = inc.ReadInt32();
                                    float x = inc.ReadFloat();
									float y = inc.ReadFloat();
                                    float z = inc.ReadFloat();
                                    string name = inc.ReadString();
									string textura = inc.ReadString();
									string imgsuperiornombre = inc.ReadString();
									imgcolorbase = inc.ReadString();
									imgcolorsuperior = inc.ReadString();
									Int16 raza = inc.ReadInt16();
									Int16 imagentipo = inc.ReadInt16();
                                    segundos = inc.ReadInt16();

                                    movimientoAstros();

                                    Vector3 position = new Vector3(x, y, z);
									GameObject p = GameObject.Instantiate(prefabPer[imagentipo], position, Quaternion.identity) as GameObject;

									p.transform.localScale = new Vector3(50f,50f,50f);
									p.transform.eulerAngles = new Vector3(90, 0, 0);
									string[] arrimgcolorbase = imgcolorbase.Split(","[0]);
									string[] arrimgcolorsup = imgcolorsuperior.Split(","[0]);
									Color colorbase = new Color(float.Parse(arrimgcolorbase[0]),float.Parse(arrimgcolorbase[1]),float.Parse(arrimgcolorbase[2]));
									Color colorsup = new Color(float.Parse(arrimgcolorsup[0]),float.Parse(arrimgcolorsup[1]),float.Parse(arrimgcolorsup[2]));				
									p.renderer.material.SetColor("_Color",colorbase);
									p.renderer.material.SetColor("_SpecColor",colorsup);

									GameObject objnombrejugador = GameObject.Instantiate(prefabTextMesh, position, Quaternion.identity) as GameObject;
                                    objnombrejugador.transform.position = position + new Vector3(0, 5f, 35f);
                                    objnombrejugador.transform.eulerAngles = new Vector3(90f, 0, 0);
                                    objnombrejugador.GetComponent<TextMesh>().text = name;
					 				objnombrejugador.GetComponent<TextMesh>().fontSize = 20;
                                    objnombrejugador.renderer.material.color = Color.white;
					
									camara.transform.position=new Vector3(p.transform.position.x,camara.transform.position.y,p.transform.position.z);		

                                    PlayerObject jugador = new PlayerObject(playerid, p, objnombrejugador);
                                    if (playerid == ClientId)
                                    {
                                        Player = jugador;
										jugador.Controller.propio = true;
                                        conectado = true;
                                    }
                                    Players.Add(jugador);
                                }
                                break;
                            case (byte)PacketTypes.Movimiento:
                                {
									if(conectado)
									{
	                                    Int32 playerid = inc.ReadInt32();
	                                    PlayerObject jugadorSelec = Players.Find(p => p.Id == playerid);
	                                    if (jugadorSelec == null) break;
	                                    float x = inc.ReadFloat();
	                                    float y = inc.ReadFloat();
										float z = inc.ReadFloat();
										float triptime = inc.ReadFloat() + roundtriptime;
						                jugadorSelec.Controller.PushUpdate(x, y, z, triptime);
									}
                                }
                                break;
							case (byte)PacketTypes.RemovePlayer:
                                {
                                    Int32 playerid = inc.ReadInt32();
                                    PlayerObject jugadorSelec = Players.Find(p => p.Id == playerid);
									Destroy (jugadorSelec.Obj);
									Players.Remove(jugadorSelec);
                                }
                                break;
							case (byte)PacketTypes.Conectado:
                                {
									conectado = true;
                                }
                                break;
							case (byte)PacketTypes.Login:
                                {
							        NetOutgoingMessage outmsg = client.CreateMessage();
							        outmsg.Write((byte)PacketTypes.Login);
							        outmsg.Write(usuario);
							        outmsg.Write(pass);
									client.SendMessage(outmsg, NetDeliveryMethod.ReliableOrdered, 0);
                                }
                                break;
							case (byte)PacketTypes.Tiempo:
                                {
                                    segundos = inc.ReadInt16();
                                    movimientoAstros();
                                }
                            break;
							case (byte)PacketTypes.Disconnect:
                                {
									//inc.Reset();
									isConnected = false;
									Application.LoadLevel("mapa");
                                }
                            break;
                            default:
                            break;
                        }
                    }
                    break;
                default:
                break;
            }
        }

	}

    void movimientoAstros()
    {
        intervaloSol = segundos / ratioSegundos;
        if (intervaloSol == 1f)
        {
            if (dia) dia = false;
            else dia = true;
            if (segundos == (ratioSegundos * 2f))
            {
                puntoBsol = Asol;
                puntoAsol = Bsol;
            }
        }
        siguientePuntoSol = Quaternion.Lerp(puntoAsol, puntoBsol, intervaloSol);
        sol.transform.rotation = siguientePuntoSol;
        intensidadSol = (maxintesidadSol * sol.transform.rotation.eulerAngles.x) / 70;
        if (intensidadSol < minintesidadSol) intensidadSol = minintesidadSol;
        sol.light.intensity = intensidadSol;
    }
	
	Texture2D crearImagen()
	{
		Texture2D imgfinal = new Texture2D(imgbase.width,imgbase.height,TextureFormat.ARGB32,true);
		
	    Color32[] colsbase = imgbase.GetPixels32();
		Color32[] colssuperior = imgsuperior.GetPixels32();
		
		Color32[] colsfinal = imgbase.GetPixels32();
		string[] arrimgcolorbase = imgcolorbase.Split(","[0]);
		Color32 colorbase = new Color32();
		colorbase.r = byte.Parse(arrimgcolorbase[0]);
		colorbase.g = byte.Parse(arrimgcolorbase[1]);
		colorbase.b = byte.Parse(arrimgcolorbase[2]);
		colorbase.a = 255;
		string[] arrimgcolorsuperior = imgcolorsuperior.Split(","[0]);
		Color32 colorsuperior = new Color32();
		colorsuperior.r = byte.Parse(arrimgcolorsuperior[0]);
		colorsuperior.g = byte.Parse(arrimgcolorsuperior[1]);
		colorsuperior.b = byte.Parse(arrimgcolorsuperior[2]);
		colorsuperior.a = 255;
		
	    for(int i = 0; i < colsbase.Length; ++i) 
		{
			// Lo que sea transparente de la img superior se dibuja la img base
	    	if(colssuperior[i].a==0) 
			{
				// Lo que sea opaco de la img base se dibuja con el color personalizado
				if(colsbase[i].a==255) 
				{
					colsfinal[i] = colorbase;
				}
			}
			// Lo que sea opaco de la img superior se dibuja con el color personalizado
			else colsfinal[i] = colorsuperior;
	    }
	    
		imgfinal.SetPixels32(colsfinal);
		//imgfinal.SetPixels32(colssuperior,1);

	    imgfinal.Apply( true );
		return imgfinal;
	}
	
	void Update () 
	{
		if (Input.GetKey (KeyCode.P)) gameObject.GetComponent<GUITestScript>().doWindowPersonaje = true;
		if (Input.GetKey (KeyCode.Escape)) 
		{
			if(gameObject.GetComponent<GUITestScript>().doWindowMenu) gameObject.GetComponent<GUITestScript>().doWindowMenu = false;
			else gameObject.GetComponent<GUITestScript>().doWindowMenu = true;
		}
		if(escucharRed) recibirNetwork();
	}

	void OnGUI () 
	{
		GUI.Label (new Rect (10, 20, 700, 700), "Mensaje="+msgalerta);
				
		Event e = Event.current;
		if(isConnected)
		{
		    if(e.button == 0 && e.isMouse &&  Event.current.type==EventType.MouseUp)
		    {
		    	if(Input.mousePosition.x>0) 
				{
	                Ray rayo = camara.camera.ScreenPointToRay(Input.mousePosition);
	  				RaycastHit hitInfo;
	                if (Physics.Raycast(rayo, out hitInfo, Mathf.Infinity, 7))
	                {
						posDestino = new Vector3(hitInfo.point.x,Player.Obj.transform.position.y,hitInfo.point.z);
						NetOutgoingMessage outmsg = new NetOutgoingMessage();
				        outmsg.Write((byte)PacketTypes.Movimiento);
				        outmsg.Write(hitInfo.point.x);
				        outmsg.Write(Player.Obj.transform.position.y);
						outmsg.Write(hitInfo.point.z);
				        client.SendMessage(outmsg, NetDeliveryMethod.ReliableOrdered,1);
	                }
				}
		    }
		}
		
		if(!activar)
		{
			GUI.backgroundColor=Color.red;
		}
		
		if(!Screen.showCursor)
		{
			Rect pos = new Rect(Input.mousePosition.x,Screen.height - Input.mousePosition.y,cursor.width*3f,cursor.height*3f);
	    	GUI.Label(pos,cursor);
		}
	}

	void OnApplicationQuit()
    {
		if(isConnected)
		{
	        NetOutgoingMessage outmsg = client.CreateMessage();
	        outmsg.Write((byte)PacketTypes.Disconnect);
	        client.SendMessage(outmsg, NetDeliveryMethod.ReliableOrdered);
			isConnected = false;
			conectado = false;
		}
    }

	void escanear()
	{
		int xx=-1;
		int zz=-1;
		string datosTerreno="";
		
		for(int x=10;x<19990;x+=movimiento)
		{
			vx++;
			vz=0;
			for(int z=10;z<19990;z+=movimiento)
			{
				vz++;	
			}
		}
		arrCols=new float[vx,vz];

		for(int x=10;x<19990;x+=movimiento)
		{
			xx++;
			zz=-1;
			for(int z=10;z<19990;z+=movimiento)
			{
				zz++;	
				if(Physics.Raycast (new Vector3(x,1000,z), new Vector3(0,-1,0), out hit))
				{
					if(hit.collider.gameObject.tag!="personaje") arrCols[xx,zz]=hit.point.y;
					else arrCols[xx,zz]=0;
					
				}
				else
				{
					arrCols[xx,zz]=0;
				}
			}
		}
		
	}
	
}


public class cAstar 
{
	public Vector3 post;
	public float x;
	public float z;
	public cAstar padre;
	public float g;
	public float h;
	public float f;
	public bool d;
	
	public cAstar(Vector3 post)
	{
		this.post=post;
		this.x=post.x;
		this.z=post.z;
		this.padre=null;
		this.g=0;
		this.h=0;
		this.f=0;
		this.d=false;
	}
}

public class cRazas 
{
	public string nombre;
	public string descrip;
	public int[] valores;
	public int[] valoresmin;
	public int[] valoresmax;
	public int valoresdistrib;
	public int valoresdistribarmas;
	public int[] valoreshabilidades;
	public int[] valoresresistencias;

	public cRazas(string nombre,string descrip,int[] valores,int[] valoresmin,int[] valoresmax, int valoresdistrib, int[] valoreshabilidades, int[] valoresresistencias, int valoresdistribarmas)
	{
		this.nombre=nombre;
		this.descrip=descrip;
		this.valores=valores;
		this.valoresmin=valoresmin;
		this.valoresmax=valoresmax;
		this.valoresdistrib=valoresdistrib;
		this.valoresdistribarmas=valoresdistribarmas;
		this.valoreshabilidades=valoreshabilidades;
		this.valoresresistencias=valoresresistencias;
	}
}