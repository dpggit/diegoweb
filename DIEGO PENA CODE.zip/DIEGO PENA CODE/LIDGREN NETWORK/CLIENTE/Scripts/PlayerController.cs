using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerController : MonoBehaviour {
	
	public GameObject nombre;
	public bool propio=false;
	
	private Vector3 RealPosition;
	private int PlayerSpeed=500;
	private GameObject camara;
	private string msgalerta;
	private Vector3 poscam;
	
	public Vector3 puntocaminoB;
	public int puntoProgreso;
	public List<Vector3> ret;
	public Vector3 destino;
	
	void Start () {
	 	RealPosition = gameObject.transform.position;
		camara=GameObject.FindGameObjectWithTag("camara");
	}
	
	
    public void PushUpdate(float x, float y, float z, float lag)
    {
		// El lag lo que hace es que el personaje no se mueva en el tiempo que el mensaje tarda en llegar al servidor
		// por lo que para compensarlo se añade al x y al z la velocidad del personaje multiplicado por el lag
		float newx = x + PlayerSpeed * lag;
        float newz = z + PlayerSpeed * lag;        
        RealPosition = new Vector3(x, y, z);

        gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, RealPosition, Time.deltaTime * PlayerSpeed);
		camara.transform.position=new Vector3(transform.position.x,camara.transform.position.y,transform.position.z);		
		nombre.transform.position=transform.position+new Vector3(0,5f,35f);
    }
	
	/*
	public void PushUpdate()
	{
		if(puntocaminoB!=Vector3.zero)
		{
			float valorh=(new Vector2(puntocaminoB.x,puntocaminoB.z)-new Vector2(transform.position.x,transform.position.z)).magnitude;
			if(puntoProgreso>0)
			{
				if(valorh==0)
				{
					puntoProgreso--;
					puntocaminoB=ret[puntoProgreso];
				}
			}
			else 
			{
				puntocaminoB=destino;
				if(valorh==0)
				{
					transform.position=destino;
					puntocaminoB=Vector3.zero;
				}
			}
			if(puntocaminoB!=Vector3.zero)
			{
				transform.position=Vector3.MoveTowards(transform.position,new Vector3(puntocaminoB.x,transform.position.y,puntocaminoB.z),Time.deltaTime*PlayerSpeed);
				camara.transform.position=new Vector3(transform.position.x,camara.transform.position.y,transform.position.z);
				nombre.transform.position=transform.position+new Vector3(0,5f,25f);
			}
		}
	}
	*/

    void OnGUI()
    {
		// se sabe la posicion de lso demas a partir de la de cada jugador, que esta siempre en el centro, asi que se calcula al distancia x y z de los demas
		// y si estan dentro de la pantalla se les dibuja
		GUI.Label (new Rect (10, 100, 700, 700), "MensajeController="+msgalerta);

    }

	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnMouseOver()
    {
        if(!propio) Screen.showCursor = false;
    } 
	
	void OnMouseExit()
    {
        Screen.showCursor = true;
    } 

}
