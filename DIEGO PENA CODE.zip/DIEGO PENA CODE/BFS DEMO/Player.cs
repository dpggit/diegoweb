﻿// Diego Pena Gayo 2014

using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	public float movementSpeedSides=10f;
	public float movementScrollUpDown=10f;
	public float movementForwBack=10f;

	Vector3 dirUp;
	Vector3 dirDown;
	Vector3 dirScrollUp;
	Vector3 dirScrollDown;

	float forBackOri;

	void Start()
	{
		forBackOri=movementForwBack;
	}

	void Update () {
		CamMovement();
	}

	void CamMovement()
	{
		if(!GameManager.Instance.topCam) 
		{
			movementForwBack=forBackOri*0.2f;
		}
		if(GameManager.Instance.topCam) 
		{
			dirUp=Vector3.up;
			dirDown=Vector3.down;
			dirScrollUp=Vector3.forward;
			dirScrollDown=Vector3.back;
		}
		else
		{
			dirUp=transform.TransformDirection(Vector3.back);
			dirDown=transform.TransformDirection(Vector3.forward);
			dirScrollUp=Vector3.up;
			dirScrollDown=Vector3.down;
		}
		float movForwBackDelta = movementForwBack*Time.deltaTime;
		if(Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) 
		{
			transform.Translate(dirUp*movForwBackDelta);
		}
		if(Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
		{
			transform.Translate(dirDown*movForwBackDelta);
		}
		float movSidesDelta = movementSpeedSides*Time.deltaTime;
		if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) transform.Translate(Vector3.left*movSidesDelta);
		if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) transform.Translate(Vector3.right*movSidesDelta);
		if(Input.GetAxis("Mouse ScrollWheel")!=0)
		{
			if(Input.GetAxis("Mouse ScrollWheel")>0) 
			{
				transform.Translate(dirScrollUp*movementScrollUpDown*Time.deltaTime);
			}
			else transform.Translate(dirScrollDown*movementScrollUpDown*Time.deltaTime);
		}
	}
}
