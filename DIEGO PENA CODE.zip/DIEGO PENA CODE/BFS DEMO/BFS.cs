﻿// Diego Pena Gayo 2014

using UnityEngine;
//using System;
using System.Collections;
using System.Collections.Generic;

public class BFS:MonoBehaviour
{
	LayerMask lmTowerene=1<<10;
	RaycastHit hit;

	public List<Node> BFSMethod(Node start, Node target, int index, int enemyId, List<Node> nodeList, bool finished, float radius)
	{
		Node final = null;
		List<float> distances=new List<float>();

		// while the queue is not empty
		if(start.position == target.position)
		{
			List<Node> nodeArray=new List<Node>();
			nodeArray.Add(start);
			return nodeArray;
		}
		// Set this one to null
		start.parent = null;
		Queue<Node>queue = new Queue<Node>();
		foreach(Node node in start.children)
		{
			// Set the parent for those node as the start node     
			if(node.blocked) continue;
			Vector3 dir = node.position-start.position;
			if(Physics.SphereCast(start.position,radius,dir, out hit,GameManager.cubeSize,lmTowerene)) 
			{
				if(hit.collider.gameObject.GetInstanceID()!=enemyId) continue;
			}
			if(GameManager.Instance.nodes.Count>256)
			{
				if(!nodeList.Contains(node)) continue;
			}
			node.parent = start;
			if(!node.blocked) queue.Enqueue(node);
		}
		// set used to true for starting node
		start.used[index] = true;
		while(queue.Count > 0)
		{
			// Get the first node of the queue
			Node n = queue.Dequeue();
			n.used[index] = true;
			// Check if target
			if(target.children.Find(p=>p.id==n.id)!=null || target.id==n.id)
			{
				final = n;
				break;
			}
			foreach(Node nod in n.children)
			{
				if(nod.used[index] || nod.blocked) continue; // Discard if already used
				Vector3 dir = nod.position-n.position;
				if(Physics.SphereCast(n.position,radius,dir, out hit,GameManager.Instance.cubeSize,lmTowerene)) 
				{
					continue;
					//Ignore the enemy itself 
					if(hit.collider.gameObject.GetInstanceID()!=enemyId) continue;
				}
				if(GameManager.Instance.nodes.Count>256)
				{
					if(!nodeList.Contains(nod)) continue;
				}
				nod.parent = n;
				queue.Enqueue(nod);
			}
		}
		// If final is null we could not find a path
		if(final == null) return null;

		// Get the parent node of the final node
		Node parent = final.parent;
		List<Node>list = new List<Node>();
		
		// While the parent is not the start node
		// This will go back up parent of each node
		// and then define the parent as current node

		while(parent != null)
		{
			list.Add(final);
			final = parent;
			parent = final.parent;
		}

		// We add the last one
		list.Add(final);

		// The list is from target to start
		// We reverse it
		list.Reverse();
		//remove first one, as it is the node where the enemy is
		//unless its making a search in a new block cause then start will not be the enemy position
		//but the next node to move
		if(!finished) list.Remove(start);
		return list;
	}
}