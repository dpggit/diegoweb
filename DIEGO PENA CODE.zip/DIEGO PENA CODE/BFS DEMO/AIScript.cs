﻿// Diego Pena Gayo 2014
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AIScript : MonoBehaviour {

	//Interval to check if a enemy is null
	public float waitTimeNull=0.2f;
	public float waitTimeStuck=0.2f;
	public float colWait=0.2f;

	[HideInInspector]
	public float f_speed;
	//when its ready to move
	[HideInInspector]
	public bool ready=false;
	[HideInInspector]
	public bool dontMove=false;

	float nextNull;
	float nextCol;
	float nextStuckTime;
	float numberNulls;

	int i_index;
	int id;
	int index;
	int lastChoosenDir;

	bool finished;
	bool initUpdate;
	bool findCrystal;
	bool lookingExit;
	bool stuck;

	Vector3 direction;
	Vector3 lastPosition;
	Vector3 lookingExitTarget;
	Vector3 gravity;

	List<Node> m_path;
	List<Node> nodes;
	List<Node> Last_m_path;
	List<Node> nullEndNodes;
	List<Vector3> dirList;
	RaycastHit[] hitArr;

	Node start;
	Node end;
	Transform m_crystal;
	BFS bfsInstance;
	RaycastHit hit;
	LayerMask lmTowerEne;
	LayerMask butGround;
	CharacterController controller;

	void Awake () {
		controller = GetComponent<CharacterController>();
		m_path=null;
		Last_m_path=null;
		start=null;
		end=null;
		stuck=false;
		findCrystal=true;
		lookingExit=false;
		finished=false;
		initUpdate=false;
		lastChoosenDir=-1;
		lookingExitTarget=Vector3.zero;
		nodes=new List<Node>();
		nullEndNodes=new List<Node>();
		gravity = new Vector3(0,-10f,0);
		dontMove=false;
		nodes = GameManager.Instance.nodes;
		lastPosition=transform.position;
		lmTowerEne=1<<9|1<<10;
		butGround=~(1<<8);
		bfsInstance=new BFS();
		id=gameObject.GetInstanceID();
		dirList=new List<Vector3>();
		dirList.Add(Vector3.right);
		dirList.Add(Vector3.left);
	}

	void Start()
	{
		start = GetClosestNode(transform.position);
		GameObject m_crystalGO=findClosestCrystal();
		m_crystal=m_crystalGO.transform;
		if(m_path == null)
		{
			//Dont make all enemy scripts seek at the same time
			//dont do anything until reach its turn in the movement queue in gamemanager
			dontMove=true;
			GameManager.Instance.EneMovQueue.Add(gameObject);
		}
		initUpdate=true;
	}

	//Reset nodes used value 
	void ResetNodes()
	{
		for(int i=0;i<nodes.Count;i++)
		{
			nodes[i].used[index]=false;
		}
	}

	//Find closest crystal to the enemy
	GameObject findClosestCrystal(GameObject notChoose=null)
	{
		float distance = float.PositiveInfinity;
		GameObject target = null;
		for(int i = 0; i < GameManager.Instance.crystalsList.Count; i++)
		{
			if(notChoose==GameManager.Instance.crystalsList[i] && GameManager.Instance.crystalsList.Count>1) continue;
			float dist = (transform.position - GameManager.Instance.crystalsList[i].transform.position).sqrMagnitude;
			if(dist <= distance)
			{
				distance = dist;
				target = GameManager.Instance.crystalsList[i];
			}
		}
		if(GameManager.Instance.crystalsList.Count==0) return null;
		else return target;
	}

	//In case of path null try getting an alternative route
	void lookingForExit()
	{
		int startingIndex = 0;
		if(lastChoosenDir!=-1) 
		{
			startingIndex=lastChoosenDir+1;
			if(startingIndex>3) startingIndex=0;
		}
		else startingIndex = Random.Range(0,2);
		int lowInd=0;
		int numberColls=0;
		int lastNumberColls=0;
		Vector3 startPos = GetClosestNode(transform.position).position;
		for(int i=0;i<2;i++)
		{
			Vector3 choosenDir = dirList[i];
			hitArr=Physics.SphereCastAll(startPos,collider.bounds.extents.x,choosenDir,GameManager.Instance.cubeSize,lmTowerEne);
			for(int j=0;j<hitArr.Length;j++)
			{
				if(hitArr[j].collider.gameObject.GetInstanceID()==id) continue;
				//if a tower dont keep counting collisions
				if(hitArr[j].collider.gameObject.layer==9) break;
				else numberColls++;
			}
			if(numberColls==0)
			{
				lowInd=i;
				break;
			}
			if(numberColls<lastNumberColls) lowInd=i;
			lastNumberColls=numberColls;
			startingIndex++;
			if(startingIndex>1) startingIndex=0;
		}
		if(end==null || m_crystal==null) return;
		Vector3 endDir = m_crystal.transform.position-transform.position;
		float sideMov = 4f+numberNulls;
		if(sideMov>9f) sideMov=9f;
		lookingExitTarget = transform.position+(dirList[lowInd]*GameManager.Instance.cubeSize)*sideMov;
		lookingExit=true;
		dontMove=true;
		//try also another target
		m_crystal=findClosestCrystal(m_crystal.gameObject).transform;
		GameManager.Instance.EneMovQueue.Add(gameObject);
	}

	void detectStuck()
	{
		//Check every some seconds if its stuck checking its controller velocity compared to the velocity of the last time
		if(Time.time>=nextStuckTime)
		{
			//need to wait more for the slower enemies or will detect they are stuck when they are not
			nextStuckTime=Time.time+waitTimeStuck+(2f/f_speed)*5f;
			if((transform.position-lastPosition).magnitude<GameManager.Instance.cubeSize*0.25f) 
			{
				numberNulls++;
				List<GameObject> cList = GameManager.Instance.crystalsList;
				List<Enemies> eList = GameManager.Instance.enemiesList;
				if(cList.Count>1 && numberNulls<cList.Count) 
				{
					m_crystal=cList[Random.Range(0,cList.Count)].transform;
					GameManager.Instance.EneMovQueue.Add(gameObject);
				}
				else if(eList.Count>1 && (numberNulls-cList.Count)<eList.Count)
				{
					m_crystal=eList[Random.Range(0,eList.Count)].obj.transform;
					GameManager.Instance.EneMovQueue.Add(gameObject);
				}
				else lookingForExit();
				//m_crystal=findClosestCrystal(m_crystal.gameObject).transform;
			}
			//last postion since a waitEnemy check was made
			lastPosition=transform.position;
		}
	}

	void LateUpdate () 
	{
		if(GameManager.Instance.start || GameManager.Instance.gameOver || GameManager.Instance.gameWin || dontMove) return;
		finished=false;
		detectColl();
		detectStuck();
		if(GameManager.Instance.crystalsList.Count==0) 
		{
			GameManager.Instance.gameOver=true;
			Time.timeScale=0;
			return;
		}
		if(m_crystal==null)
		{
			m_crystal=findClosestCrystal().transform;
			dontMove=true;
			GameManager.Instance.EneMovQueue.Add(gameObject);
		}
		else if(m_path==null)
		{
			//if already had its turn to move in GameManager, if not it would be null
			if(ready)
			{
				direction = (m_crystal.transform.position - transform.position).normalized+gravity;
				controller.Move(direction * Time.deltaTime * f_speed);
				//Wait some time until check again if null to give some time to move out of the area where got a null
				if(Time.time>nextNull)
				{
					nextNull=Time.time+waitTimeNull+(2f/f_speed)*3f;
					numberNulls++;
					List<GameObject> cList = GameManager.Instance.crystalsList;
					List<Enemies> eList = GameManager.Instance.enemiesList;
					if(cList.Count>1 && numberNulls<cList.Count) 
					{
						m_crystal=cList[Random.Range(0,cList.Count)].transform;
						GameManager.Instance.EneMovQueue.Add(gameObject);
					}
					else if(eList.Count>1 && (numberNulls-cList.Count)<eList.Count)
					{
						m_crystal=eList[Random.Range(0,eList.Count)].obj.transform;
						GameManager.Instance.EneMovQueue.Add(gameObject);
					}
					else lookingForExit();
				}
			}
		}
		else
		{
			if(i_index == m_path.Count)
			{
				finished=true;
				//dont do anything until reach its turn in the movement queue in gamemanager
				dontMove=true;
				GameManager.Instance.EneMovQueue.Add(gameObject);
			}
			else
			{
				if(findCrystal)
				{
					m_crystal=findClosestCrystal().transform;
					findCrystal=false;
				}
				Vector3 position = m_path[i_index].position;
				direction = (position - transform.position).normalized+gravity;
				controller.Move(direction * Time.deltaTime * f_speed);
				//if very near the node go to the next node
				if((position - transform.position).sqrMagnitude < 0.2f) i_index++;
			}
		}
	}

	//Find nearest node to the crystal i am targeting
	Node nearestToCrystal()
	{
		if(nodes.Count==0) return null;
		float distance = float.PositiveInfinity;
		Node target = null;
		for(int i = 0; i < nodes.Count; i++)
		{
			if(nodes[i].blocked || nullEndNodes.Contains(nodes[i])) continue;
			float dist = (m_crystal.transform.position - nodes[i].position).sqrMagnitude;
			if(dist <= distance)
			{
				distance = dist;
				target = nodes[i];
			}
		}
		return target;
	}

	//Pathfinding method
	public void AIMethod(){
		findCrystal=true;
		if(GameManager.Instance.crystalsList.Count>0)
		{
			if(m_crystal==null) m_crystal=findClosestCrystal().transform;
			i_index = 0;
			nodes=GameManager.Instance.nodes;
			if(nodes.Count>256)
			{
				Vector3 dir=m_crystal.position-transform.position;
				//if reached the end of the path for that block of nodes find the nearest node in the next block
				//It cant be a blocked node, if the closest node is blocked it could search the next nearest  
				//and that one could be in the same block list and not in a new one as should
				if(finished) 
				{
					start = GetClosestNode(transform.position+dir.normalized*GameManager.Instance.cubeSize,true);
					//Need a node in the new block that is not blocked and also neighbour of the node where is the enemy
					if(start.blocked)
					{
						foreach(Node n in start.children)
						{
							if(n.blocked || n.blockPos==start.blockPos) continue;
							start=n;
						}
					}
				}
				//If start blocked or not trying to find a new block of nodes, finish is true when reach the nearest node of that block to the crystal
				if(!finished) start = GetClosestNode(transform.position);
				//the start will be a node of the new block, 
				//if blocked will have to make a new search for another node in the old block ignoring the last node
				else if(start.blocked) start = end;
				//get the list of nodes for the block where is the enemy
				nodes=GameManager.Instance.areaBlocks[(int)start.blockPos.x][(int)start.blockPos.y];
			}
			else start = GetClosestNode(transform.position);
			if(start==null) 
			{
				m_path=null;
				return;
			}
			ResetNodes();
			//Get the node nearest to the crystal in the list of nodes where is the enemy
			if(lookingExit) 
			{
				end=GetClosestNode(lookingExitTarget);
				lookingExit=false;
				lastChoosenDir=-1;
			}
			else
			{
				if(GameManager.Instance.nodes.Count>256) 
				{
					if(start==end) 
					{
						nullEndNodes.Clear();
						nullEndNodes.Add(start);
					}
					//if path null find the node nearest to crystal discarding the previous null end nodes
					end = nearestToCrystal();
				}
				else end = GetClosestNode(m_crystal.transform.position);
			}
			foreach(Enemies e in GameManager.Instance.enemiesList)
			{
				if(e.id==id)
				{
					index = e.index;
					break;
				}
			}
			m_path = bfsInstance.BFSMethod(start, end, index, id, nodes, finished, collider.bounds.extents.x);
			if(m_path==null) nullEndNodes.Add (end);
			else
			{
				nullEndNodes.Clear();
				Last_m_path=m_path;
				numberNulls=0;
			}
		}
	}

	//Get the closest node to a position
	public Node GetClosestNode(Vector3 position, bool alsoBlocked=false){
		float distance = float.PositiveInfinity;
		Node target = null;
		for(int i = 0; i < nodes.Count; i++)
		{
			if(nodes[i].blocked && !alsoBlocked) continue;
			float dist = (position - nodes[i].position).sqrMagnitude;
			if(dist <= distance)
			{
				distance = dist;
				target = nodes[i];
			}
		}
		return target;
	}

	//Detect collisions
	void detectColl()
	{
		if(direction!=Vector3.zero) 
		{
			Quaternion oldRot = transform.rotation;
			transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), 20f * Time.deltaTime);
			transform.rotation=new Quaternion(oldRot.x,transform.rotation.y,oldRot.z,oldRot.w);
		}
		Vector3 tPos=transform.TransformPoint(Vector3.forward);
		if(Physics.SphereCast(transform.position,collider.bounds.extents.x,transform.forward,out hit,GameManager.Instance.cubeSize,butGround))
		{
			Collider col = hit.collider;
			GameObject colGO = col.gameObject;
			//When a path is made was taking in account the positions of the enemies in that moment
			//once start moving the path can be outdated
			if(colGO.layer==10)
			{
				//so that is not finding a path every frame
				if(Time.time>nextCol)
				{
					nextCol=Time.time+colWait;
					dontMove=true;
					GameManager.Instance.EneMovQueue.Add(gameObject);
				}
			}
			else if(colGO.layer==11)
			{
				GameObject crystal = GameManager.Instance.crystalsList.Find(p=>p.GetInstanceID()==colGO.GetInstanceID());
				GameManager.Instance.crystalsList.Remove(crystal);
				Destroy(colGO);
			}
		}
	}
}