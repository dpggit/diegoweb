﻿// Diego Pena Gayo 2014

using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif
using System.Collections;
using System.Collections.Generic;


public class Node
{
	public int id;
	public Node parent;
	public List<Node> children;
	public bool[] used;
	public bool blocked=false;
	public Vector3 position;
	public Vector2 blockPos;

	public Node(int id,Vector3 position,bool blocked, bool[] used, Vector2 blockPos)
	{
		this.id=id;
		this.position=position;
		this.blocked=blocked;
		this.used=used;
		this.blockPos=blockPos;
	}
}

public class Towers
{
	public int id;
	public GameObject obj;
	public string name;
	public Color color;
	public Color actualColor;
	public Vector3 position;
	public GameObject upgradeBar;
	public GameObject upgradeBarBack;
	public Vector3 lastBarScale;
	public Vector3 newBarScale;
	public float lastBarTime;
	public float progress;
	public float firePower=1f;
	public float nextFirePower=1f;

	public Towers(int id,GameObject obj,Color color,Vector3 position,GameObject upgradeBar,GameObject upgradeBarBack)
	{
		this.id=id;
		this.obj=obj;
		this.color=color;
		this.actualColor=color;
		this.position=position;
		this.upgradeBar=upgradeBar;
		this.upgradeBarBack=upgradeBarBack;
	}
}

public enum enemyTypes{Soldier,Knight,Champion}

public class Enemies
{
	public int id;
	public GameObject obj;
	public string name;
	public Color color;
	public Vector3 position;
	public GameObject healthBar;
	public GameObject healthBarBack;
	public Vector3 lastBarScale;
	public Vector3 newBarScale;
	public float lastBarTime;
	public float speed;
	public enemyTypes type;
	public float maxLife;
	public float life;
	public int index;
	public int level;

	public Enemies(int id,enemyTypes type,GameObject obj,float speed,Color color,Vector3 position,GameObject healthBar,GameObject healthBarBack,float maxLife, int index, int level)
	{
		this.id=id;
		this.type=type;
		this.obj=obj;
		this.speed=speed;
		this.color=color;
		this.position=position;
		this.healthBar=healthBar;
		this.healthBarBack=healthBarBack;
		this.index=index;
		this.maxLife=maxLife;
		this.life=maxLife;
		this.level=level;
	}
}


public class GameManager : MonoBehaviour {
	public Transform cellParent;
	public Transform towerParent;
	public Transform enemyParent;
	public Transform crystalParent;

	public GameObject cam;
	public GameObject gridProjector;
	public GameObject enemyPrefab;
	public GameObject groundPrefab;
	public GameObject cellPrefab;
	public GameObject tower1x1Prefab;
	public GameObject tower1x2Prefab;
	public GameObject progressBar;
	public GameObject healthBar;
	public GameObject crystalPrefab;

	//Number of cells of fire range
	public float towersFireRadius=5f;
	public float enemiesBaseSpeed=10f;
	public float lifeOfSoldiers=15;
	public float lifeOfKnights=20;
	public float lifeOfChampions=25;
	public float StartingCamHeight=4;
	public float placingTowerRate=0.1f;
	public float progressBarSpeed=0.05f;
	public float towerRadius=2f;

	public int CellsWidth=32;
	public int CellsHeight=32;
	public int divided=10;
	public int startingMoney=50000;
	public int numberOfSoldiers=10;
	public int numberOfKnights=5;
	public int numberOfChampions=2;
	public int numberOfCrystals=10;

	public bool centerObjects=true;
	//Can be black and white or using a projector to divide the grid,
	//black and white uses cubes gameobject so is more expensive
	public bool BlackWhiteGrid=false;
	public bool barsLookAtCamera=false;

	public float cubeSize;
	public float halfCubeSize;
	public float fireRange;
	public bool gameOver;
	public bool gameWin;
	public bool start;
	public bool topCam;
	public int money;
	public int gameLength;
	public int gameWidth;
	public int gameHeight;
	public int diffId=0;
	public List<Node> nodes;
	public List<List<Node>> tiles;
	public List<Enemies> enemiesList;
	public List<Node>[][] areaBlocks;
	public List<GameObject> crystalsList;
	public List<GameObject> EneMovQueue;
	public List<Towers> towerList;
	public List<Towers> towerListProgress;
	public Vector3 startPos;
    public static GameManager Instance;

    float CellCubeSize;
	float CellsWidthHalf;
	float CellsHeightHalf;
	float nextTower;
	float hSbarValue;
	float barRatio;
	float CellCubeSizeHalf;
	float lastBarTime;
	float overGroundHeight;
	float nextFirePower;
	float sizePow;

	int totalCells;
	int tl;
	int numberOfEnemies;
	int numberOfPrefabTowersTypes;

	bool towerSelected;
	bool stylesSet;
	bool blackWhiteGridOn;

	Vector3 lastBarScale;
	Vector3 newBarScale;
	Vector3 camOriPos;
	GameObject ground;
	GameObject tower;
	LayerMask lmNotGround;
	LayerMask lmNotGroundCubes;
	RaycastHit hitInfo;
	Towers choosenTower;
	Rect towerRect;
	GUIStyle guiStyle1;
	GUIStyle guiStyle2;
	GUIStyle guiStyle3;
	Projector gridProjComp;
	
	void Awake () {
        //Create Singleton
        if (Instance != null) Destroy(gameObject);
        else Instance = this;
        generalSetup();
		cellTowerSetup();
		setCells();
		nodesSetup();
		enemiesSetup();
		crystalsSetup();
		grid();
	}

	void generalSetup()
	{
		start=true;
		towerSelected=false;
		stylesSet=false;
		topCam=false;
		CellCubeSize=2f;
		numberOfPrefabTowersTypes=2;
		EneMovQueue=new List<GameObject>();
		gameLength=CellsHeight;
		money=startingMoney;
		fireRange=Mathf.Pow(towersFireRadius*CellCubeSize,2f);
		lmNotGround=~(1<<8);
		lmNotGroundCubes=~(1<<12);
		Time.timeScale=1f;
		sizePow=Mathf.Pow(CellCubeSize,2f);
		CellCubeSizeHalf=CellCubeSize*0.5f;
		gameOver=false;
		gameWin=false;
		MouseLook.block=false;
		gameWidth=CellsWidth;
		gameHeight=CellsHeight;
		camOriPos=cam.transform.position;
	}
	//Get the closest node to a position
	public Node GetClosestNode(Vector3 position){
		float distance = float.PositiveInfinity;
		Node target = null;
		for(int i = 0; i < nodes.Count; i++)
		{
			if(nodes[i].blocked) continue;
			float dist = (position - nodes[i].position).sqrMagnitude;
			if(dist <= distance)
			{
				distance = dist;
				target = nodes[i];
			}
		}
		return target;
	}
	//Set the grid using a grid projector
	void grid()
	{
		blackWhiteGridOn=BlackWhiteGrid;
		Transform groundT=ground.transform;
		gridProjComp=gridProjector.GetComponent<Projector>();
		float posy = cam.transform.position.y-15f+ground.renderer.bounds.extents.y;
		gridProjector.transform.position=new Vector3(groundT.position.x,posy,groundT.position.z);
		gridProjector.transform.localEulerAngles=new Vector3(90f,0,0);
		gridProjComp.orthographicSize=CellCubeSizeHalf;
		if(BlackWhiteGrid) 
		{
			gridProjComp.enabled=false;
			ground.renderer.enabled=false;
		}
	}
	//Cell and tower variables setup
	void cellTowerSetup()
	{
		cubeSize=CellCubeSize;
		halfCubeSize=CellCubeSizeHalf;
		totalCells=CellsWidth*CellsHeight;
		//if(totalCells==256) divided=16;
		towerList=new List<Towers>();
		towerListProgress=new List<Towers>();
		cam.camera.farClipPlane=totalCells*CellCubeSize*0.2f;
		startPos=cam.transform.position-new Vector3(0,StartingCamHeight,0);
		overGroundHeight=startPos.y+CellCubeSizeHalf-StartingCamHeight;
		CellsWidthHalf=Mathf.FloorToInt(CellsWidth*0.5f);
		CellsHeightHalf=Mathf.FloorToInt(CellsHeight*0.5f);
		towerRect=new Rect(0,0,100f,100f);
		barRatio=1f/5f;
	}
	//Create crystals
	void crystalsSetup()
	{
		crystalsList=new List<GameObject>();
		float border= 0;
		if(centerObjects) border= CellsWidth*CellCubeSize*0.5f-numberOfCrystals*CellCubeSize;
		for(int i=0;i<numberOfCrystals;i++)
		{
			GameObject crystalgo = Instantiate(crystalPrefab,Vector3.zero,Quaternion.identity) as GameObject;
			crystalgo.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			crystalgo.transform.parent=crystalParent;
			Color c = Color.white;
			crystalgo.renderer.material.color=c;
			float xpos = (startPos.x-CellsWidthHalf*CellCubeSize)+((i%CellsWidth)*CellCubeSize*2f)+border;
			float zpos = (startPos.z-2f*CellCubeSize)-((i/CellsWidth)*CellCubeSize*2f);
			Vector3 cryspos = new Vector3(xpos,startPos.y-CellCubeSize-StartingCamHeight+CellCubeSize*1.5f,zpos);
			crystalgo.transform.position=cryspos;
			crystalsList.Add(crystalgo);
		}
	}
	//Create enemies
	void enemiesSetup()
	{
		enemiesList=new List<Enemies>();
		float border= 0;
		if(centerObjects && numberOfEnemies*CellCubeSize*2f<=CellsWidth*CellCubeSize) border= CellsWidth*CellCubeSize*0.5f-numberOfEnemies*CellCubeSize;
		for(int i=0;i<numberOfSoldiers;i++)
		{
			GameObject enego = Instantiate(enemyPrefab,Vector3.zero,Quaternion.identity) as GameObject;
			enego.GetComponent<AIScript>().f_speed=enemiesBaseSpeed;
			enego.transform.localScale*=CellCubeSize;
			enego.transform.parent=enemyParent;
			Color c = Color.green;
			enego.renderer.material.color=c;
			enego.name="Soldier";
			float basex = (startPos.x-CellsWidthHalf*CellCubeSize);
			float xpos = basex+(((i*2)%CellsWidth)*CellCubeSize)+border;
			float zpos = (startPos.z-CellsHeight*CellCubeSize)+(((i*2)/CellsWidth)*CellCubeSize*2f);
			Vector3 enepos = new Vector3(xpos,overGroundHeight,zpos);
			enego.transform.position=enepos;
			Vector3 barPosition = enepos+new Vector3(0,enego.transform.localScale.y*1.5f,0);
			GameObject hbar = Instantiate(healthBar,barPosition,Quaternion.identity) as GameObject;
			hbar.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			hbar.transform.parent=enego.transform;
			GameObject hbarBack = Instantiate(healthBar,barPosition,Quaternion.identity) as GameObject;
			hbarBack.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			hbarBack.renderer.material.color=Color.red*0.5f;
			hbarBack.transform.parent=enego.transform;
			enemiesList.Add(new Enemies(enego.GetInstanceID(),enemyTypes.Soldier,enego,enemiesBaseSpeed,c,enepos,hbar,hbarBack,lifeOfSoldiers,i,1));
		}
		for(int i=numberOfSoldiers;i<numberOfKnights+numberOfSoldiers;i++)
		{
			GameObject enego = Instantiate(enemyPrefab,Vector3.zero,Quaternion.identity) as GameObject;
			float speed = enemiesBaseSpeed*1.5f;
			enego.GetComponent<AIScript>().f_speed=speed;
			enego.transform.localScale*=CellCubeSize;
			enego.transform.parent=enemyParent;
			Color c = Color.magenta;
			enego.renderer.material.color=c;
			enego.name="Knight";
			float basex = (startPos.x-CellsWidthHalf*CellCubeSize);
			float xpos = basex+(((i*2)%CellsWidth)*CellCubeSize)+border;
			float zpos = (startPos.z-CellsHeight*CellCubeSize)+(((i*2)/CellsWidth)*CellCubeSize*2f);
			Vector3 enepos = new Vector3(xpos,overGroundHeight,zpos);
			enego.transform.position=enepos;
			Vector3 barPosition = enepos+new Vector3(0,enego.transform.localScale.y*1.5f,0);
			GameObject hbar = Instantiate(healthBar,barPosition,Quaternion.identity) as GameObject;
			hbar.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			hbar.transform.parent=enego.transform;
			GameObject hbarBack = Instantiate(healthBar,barPosition,Quaternion.identity) as GameObject;
			hbarBack.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			hbarBack.renderer.material.color=Color.red*0.5f;
			hbarBack.transform.parent=enego.transform;
			enemiesList.Add(new Enemies(enego.GetInstanceID(),enemyTypes.Soldier,enego,speed,c,enepos,hbar,hbarBack,lifeOfKnights,i,2));
		}
		int sumforces = numberOfSoldiers+numberOfKnights;
		for(int i=sumforces;i<numberOfChampions+sumforces;i++)
		{
			GameObject enego = Instantiate(enemyPrefab,Vector3.zero,Quaternion.identity) as GameObject;
			float speed = enemiesBaseSpeed*2f;
			enego.GetComponent<AIScript>().f_speed=speed;
			enego.transform.localScale*=CellCubeSize;
			enego.transform.parent=enemyParent;
			Color c = Color.magenta*0.25f;
			enego.renderer.material.color=c;
			enego.name="Champion";
			float basex = (startPos.x-CellsWidthHalf*CellCubeSize);
			float xpos = basex+(((i*2)%CellsWidth)*CellCubeSize)+border;
			float zpos = (startPos.z-CellsHeight*CellCubeSize)+(((i*2)/CellsWidth)*CellCubeSize*2f);
			Vector3 enepos = new Vector3(xpos,overGroundHeight,zpos);
			enego.transform.position=enepos;
			Vector3 barPosition = enepos+new Vector3(0,enego.transform.localScale.y*1.5f,0);
			GameObject hbar = Instantiate(healthBar,barPosition,Quaternion.identity) as GameObject;
			hbar.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			hbar.transform.parent=enego.transform;
			GameObject hbarBack = Instantiate(healthBar,barPosition,Quaternion.identity) as GameObject;
			hbarBack.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
			hbarBack.renderer.material.color=Color.red*0.5f;
			hbarBack.transform.parent=enego.transform;
			enemiesList.Add(new Enemies(enego.GetInstanceID(),enemyTypes.Soldier,enego,speed,c,enepos,hbar,hbarBack,lifeOfChampions,i,3));
		}
	}
	//Create ground, nodes, and black and white cells if enabled
	void setCells()
	{
		int cWidth = Mathf.CeilToInt(CellsWidth/(float)divided);
		int cHeight = Mathf.CeilToInt(CellsHeight/(float)divided);
		//Divide maps in blocks of 16x16 max so that BFS can be done for big maps too
		areaBlocks=new List<Node>[cWidth][];
		tiles = new List<List<Node>>();
		nodes=new List<Node>();
		int n=0;
		float groundHeight=startPos.y-CellCubeSize-StartingCamHeight;
		numberOfEnemies=numberOfSoldiers+numberOfKnights+numberOfChampions;
		float xpos = (startPos.x-CellsWidthHalf*CellCubeSize)+(CellsWidthHalf*CellCubeSize)-CellCubeSizeHalf;
		float zpos = (startPos.z-CellsHeight*CellCubeSize)+(CellsHeightHalf*CellCubeSize)-CellCubeSizeHalf;
		Vector3 groundPos =new Vector3(xpos,groundHeight,zpos);
		Vector3 nodePos=Vector3.zero;
		ground = Instantiate(groundPrefab,groundPos,Quaternion.identity) as GameObject;
		ground.transform.localScale=new Vector3(CellCubeSize*(CellsWidth),CellCubeSize,CellCubeSize*(CellsHeight));
		changeCamView();
		for(int x=0;x<CellsWidth;x++)
		{
			int abIndexX = Mathf.FloorToInt(x/divided);
			if(areaBlocks[abIndexX]==null) 
			{
				areaBlocks[abIndexX]=new List<Node>[cHeight];
			}
			tiles.Add(new List<Node>());
			for(int y=0;y<CellsHeight;y++)
			{
				int abIndexY = Mathf.FloorToInt(y/divided);
				if(areaBlocks[abIndexX][abIndexY]==null) areaBlocks[abIndexX][abIndexY]=new List<Node>();
				//if(areaBlocks[abIndexX][abIndexY]==null) areaBlocks[abIndexX][abIndexY]=new List<Node>();
				xpos = (startPos.x-CellsWidthHalf*CellCubeSize)+(x*CellCubeSize);
				zpos = (startPos.z-CellsHeight*CellCubeSize)+(y*CellCubeSize);
				nodePos =new Vector3(xpos,overGroundHeight,zpos);
				Node newNode = new Node(n,nodePos,false,new bool[numberOfEnemies],new Vector2(abIndexX,abIndexY));
				tiles[x].Add(newNode);
				nodes.Add(newNode);
				areaBlocks[abIndexX][abIndexY].Add(newNode);
				n++;
				if(BlackWhiteGrid)
				{
					nodePos =new Vector3(xpos,groundHeight,zpos);
					GameObject cube = Instantiate(cellPrefab,nodePos,Quaternion.identity) as GameObject;
					cube.transform.localScale=new Vector3(CellCubeSize,CellCubeSize,CellCubeSize);
					bool c=false;
					if((x+y)%2f==0) c=false;
					else c=true;
					cube.renderer.material.color=c?Color.black:Color.white;
					cube.transform.parent=cellParent;
				}
			}
		}
	}
	//Set the children nodes of every parent node
	void nodesSetup()
	{
		for(int x=0;x<CellsWidth;x++)
		{
			for(int y=0;y<CellsHeight;y++)
			{
				List<Node> cd = new List<Node>();
				if((y+1)<CellsHeight)  cd.Add(tiles[x][y+1]);
				if((y-1)>=0)  cd.Add(tiles[x][y-1]);
				if((x-1)>=0)  cd.Add(tiles[x-1][y]);
				if((x+1)<CellsWidth)  cd.Add(tiles[x+1][y]);
				tiles[x][y].children=cd;
			}
		}
	}

	void setStyle()
	{
		guiStyle1=new GUIStyle();
		guiStyle1.fontSize=20;
		guiStyle1.alignment=TextAnchor.MiddleCenter;
		guiStyle2=GUI.skin.label;
		guiStyle2.fontSize=40;
		guiStyle2.alignment=TextAnchor.MiddleCenter;
		guiStyle2.fontStyle=FontStyle.Bold;
		guiStyle3=GUI.skin.button;
		guiStyle3.fontSize=14;
		guiStyle3.alignment=TextAnchor.MiddleCenter;
		guiStyle3.fontStyle=FontStyle.Bold;
		stylesSet=true;
	}

	void OnGUI()
	{
		if(!stylesSet) setStyle();
		if(gameOver)
		{
			MouseLook.block=true;
			GUI.color=Color.yellow;
			string text = "GAME OVER"+
				"\nPress any key to start again";
			float width=700f;
			GUI.Label (new Rect(Screen.width*0.5f-width*0.5f,Screen.height*0.5f-100f,width,200f),text,guiStyle2);
		}
		else if(gameWin)
		{
			MouseLook.block=true;
			GUI.color=Color.yellow;
			string text = "YOU WIN!"+
				"\nPress any key to start again";
			float width=700f;
			GUI.Label (new Rect(Screen.width*0.5f-width*0.5f,Screen.height*0.5f-100f,width,200f),text,guiStyle2);
		}
		//Start message
		else if(start)
		{
			MouseLook.block=true;
			GUI.color=Color.white;
			string text = "Use arrow keys to move the camera or WSAD keys"+
				"\nUse the mouse center button to change of tower type"+
					"\nUse the mouse right button hold to change camera rotation"+
					"\nUse the mouse scroll wheel to go up and down with the camera"+
					"\nSelect the towers with the mouse left button to select an upgrade option"+
					"\nPause the game with SPACE key and quit the game with ESC key"+
					"\nPress F1 for Top view";
			float width=600f;
			GUI.Button (new Rect(Screen.width*0.5f-width*0.5f,Screen.height*0.5f-100f,width,200f),text,guiStyle3);
			if(GUI.Button (new Rect(Screen.width*0.5f-width*0.5f,Screen.height*0.5f+100f,width,50F),"CONTINUE"))
			{
				Time.timeScale=1f;
				//cam.GetComponent<MouseLook>().axes=MouseLook.RotationAxes.MouseXAndY;
				start=false;
				gameOver=false;
				gameWin=false;
				MouseLook.block=false;
			}
		}
		//Tower upgrade options buttons
		else
		{
			GUI.Label(new Rect(Screen.width-150f,0,150f,50f),"Money :"+money,guiStyle1);
			if(towerSelected)
			{
				GUI.BeginGroup (new Rect (Screen.width*0.5f - 250f, Screen.height*0.75f - 50f, 500f, 100f));
				bool useOptions=false;
				float mod=1f;
				if(tl==1) mod=0.5f;
				if(GUI.Button (new Rect(0,0,100f,100f),"No Upgrade"))
				{
					//Set back to original color
					MouseLook.block=false;
					choosenTower.obj.renderer.material.color=choosenTower.actualColor;
					towerSelected=false;
				}
				if(choosenTower.firePower<2f)
				{
					if(GUI.Button (new Rect(100f,0,100f,100f),"Turret"+"\nLevel 2"+"\nCost 200"))
					{
						choosenTower.newBarScale=new Vector3(barRatio*2f*mod,1f,1f);
						money-=200;
						choosenTower.nextFirePower=2f;
						towerSelected=false;
						useOptions=true;
					}
				}
				if(choosenTower.firePower<3f)
				{
					if(GUI.Button (new Rect(200f,0,100f,100f),"Turret"+"\nLevel 3"+"\nCost 300"))
					{
						choosenTower.newBarScale=new Vector3(barRatio*3f*mod,1f,1f);
						money-=300;
						choosenTower.nextFirePower=3f;
						towerSelected=false;
						useOptions=true;
					}
				}
				if(choosenTower.firePower<4f)
				{
					if(GUI.Button (new Rect(300f,0,100f,100f),"Turret"+"\nLevel 4"+"\nCost 400"))
					{
						choosenTower.newBarScale=new Vector3(barRatio*4f*mod,1f,1f);
						money-=400;
						choosenTower.nextFirePower=4f;
						towerSelected=false;
						useOptions=true;
					}
				}
				if(choosenTower.firePower<5f)
				{
					if(GUI.Button (new Rect(400f,0,100f,100f),"Turret"+"\nLevel 5"+"\nCost 500"))
					{
						choosenTower.newBarScale=new Vector3(barRatio*5f*mod,1f,1f);
						money-=500;
						choosenTower.nextFirePower=5f;
						towerSelected=false;
						useOptions=true;
					}
				}
				if(useOptions)
				{
					if(!towerListProgress.Contains(choosenTower)) towerListProgress.Add(choosenTower);
					MouseLook.block=false;
					choosenTower.lastBarTime=Time.time;
					choosenTower.upgradeBar.renderer.enabled=true;
					choosenTower.upgradeBarBack.renderer.enabled=true;
					choosenTower.lastBarScale=choosenTower.upgradeBar.transform.localScale;
					//tower level in case of need to be used
					++choosenTower.progress;
				}
				GUI.EndGroup ();
			}
			//Messages in the left corner of screen showing what kind of tower is selected to create
			if(tl==0) 
			{
				GUI.color=new Color(0.5f,0.5f,1f,1f);
				GUI.Button (towerRect,"Turret"+"\n1x1");
			}
			else if(tl==1) 
			{
				GUI.color=Color.red;
				GUI.Button (towerRect,"Turret"+"\n1x2");
			}
		}
	}

	void changeCamView()
	{
		if(topCam) 
		{
			cam.transform.position=ground.transform.position+new Vector3(0,StartingCamHeight*5f,0);
			cam.GetComponent<MouseLook>().axes=MouseLook.RotationAxes.Top;
			cam.transform.localEulerAngles=new Vector3(90f,180f,0);
		}
		else 
		{
			cam.transform.position=camOriPos;
			cam.transform.localEulerAngles=new Vector3(45f,180f,0);
			cam.GetComponent<MouseLook>().rotationY=-45f;
			cam.GetComponent<MouseLook>().axes=MouseLook.RotationAxes.MouseXAndY;
		}
	}
	
	//Input controls
	void controlsCheck()
	{
		//if gameover or win load level again
		if(gameOver || gameWin)
		{
			if(Input.anyKeyDown) Application.LoadLevel(0);
		}
		//Top view
		if(Input.GetKeyDown(KeyCode.F1))
		{
			topCam=topCam?false:true;
			changeCamView();
		}
		//Quit application, just for builds
		if(Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();
		}
		//Pause game
		if(Input.GetKeyDown(KeyCode.Space))
		{
			if(Time.timeScale==0) Time.timeScale=1f;
			else Time.timeScale=0;
		}
		//If blacn and white option is enabled can switch on and off black and white cells or grid projector
		if(Input.GetKeyDown(KeyCode.G)) 
		{
			if(blackWhiteGridOn)
			{
				BlackWhiteGrid=BlackWhiteGrid?false:true;
				if(BlackWhiteGrid) 
				{
					cam.camera.cullingMask=lmNotGround;
					gridProjComp.enabled=false;
					//to avoid z fighting
					ground.renderer.enabled=false;
				}
				else 
				{
					cam.camera.cullingMask=lmNotGroundCubes;
					gridProjComp.enabled=true;
					ground.renderer.enabled=true;
				}
			}
		}
		//Center mouse button to change type of tower to create
		if(Input.GetKeyDown(KeyCode.Mouse2))
		{
			if(gameOver || gameWin) return;
			tl++;
			if(tl>=numberOfPrefabTowersTypes) tl=0;
		}
		//To place towers with the mouse over the ground
		if(Input.GetKeyDown(KeyCode.Mouse0) && !towerSelected)
		{
			if(gameOver || gameWin) return;
			if(Time.time>nextTower)
			{
				nextTower=Time.time+placingTowerRate;
			}
			else return;
			Ray rayo = cam.camera.ScreenPointToRay(Input.mousePosition);
			if (Physics.Raycast(rayo, out hitInfo, Mathf.Infinity))
			{
				GameObject obj = hitInfo.collider.gameObject;
				Vector3 position=Vector3.zero;
				Vector3 objPos = obj.transform.position;
				Color color;
				if(obj.layer==8)
				{
					Node nod = GetClosestNode(hitInfo.point);
					position = nod.position;
					Node nod2=null;
					money-=100;
					//Not valid a cell where is an enemy on it
					if(enemiesList.Find(p=>(p.obj.transform.position-nod.position).sqrMagnitude<(sizePow*0.5f))==null) 
					{
						//If collides with anything dont create it

						if(Physics.CheckSphere(position,towerRadius*CellCubeSize,lmNotGround)) return;
						//if(Physics.CheckSphere(position,CellCubeSizeHalf)) return;
						//If it is the 1x2 tower set to blocked its two cells
						if(tl==1) 
						{
							Vector3 newPos = position+new Vector3(CellCubeSizeHalf,0,0);
							if(Physics.CheckSphere(newPos,towerRadius*CellCubeSize*1.5f,lmNotGround)) return;
							//if(Physics.CheckSphere(newPos,CellCubeSizeHalf)) return;
							nod2=GetClosestNode(newPos+new Vector3(CellCubeSizeHalf,0,0));
							tower = Instantiate(tower1x2Prefab,newPos,Quaternion.identity) as GameObject;
							tower.transform.localScale*=CellCubeSize;
							color=Color.red;
							tower.renderer.material.color=color;
							tower.GetComponent<LineRenderer>().material.color=new Color(1f,0.75f,0,1f);
							tower.renderer.material.color=color;
						}
						else
						{
							tower = Instantiate(tower1x1Prefab,position,Quaternion.identity) as GameObject;
							tower.transform.localScale*=CellCubeSize;
							color=Color.blue;
							tower.renderer.material.color=color;
						}
						//Once we are sure its going to be place block the node/s
						nod.blocked=true;
						if(nod2!=null) nod2.blocked=true;
						Vector3 barPosition = position+new Vector3(0,tower.transform.localScale.y*0.75f,CellCubeSizeHalf);
						tower.transform.parent=towerParent;
						GameObject upgradeBar = Instantiate(progressBar,barPosition,Quaternion.identity) as GameObject;
						upgradeBar.transform.localScale=new Vector3(0,CellCubeSize*2f,CellCubeSize);
						upgradeBar.transform.parent=tower.transform;
						upgradeBar.renderer.enabled=false;
						GameObject upgradeBarBack = Instantiate(progressBar,barPosition,Quaternion.identity) as GameObject;
						upgradeBarBack.transform.localScale=new Vector3(CellCubeSize,CellCubeSize*2.05f,CellCubeSize);
						upgradeBarBack.renderer.material.color*=0.5f;
						upgradeBarBack.transform.parent=tower.transform;
						upgradeBarBack.renderer.enabled=false;
						towerList.Add(new Towers(tower.GetInstanceID(),tower,color,position,upgradeBar,upgradeBarBack));
						//Clear the movement queue and refresh the path for all enemies so that know about the new blocked nodes
						EneMovQueue.Clear();
						for(int i=0;i<enemiesList.Count;i++)
						{
							//dont do anything until reach its turn in the movement queue in gamemanager
							enemiesList[i].obj.GetComponent<AIScript>().dontMove=true;
							EneMovQueue.Add(enemiesList[i].obj);
						}
					}
				}
				else if(obj.layer==9)
				{
					choosenTower = towerList.Find(p=>p.id==obj.GetInstanceID());
					//if not in progress to get a better tower
					if(!choosenTower.upgradeBar.renderer.enabled)
					{
						obj.renderer.material.color=choosenTower.color*3f;
						towerSelected=true;
						MouseLook.block=true;
					}
				}
			}
		}
	}
	//Control towers progression bars
	void barsCheck()
	{
		for(int i=0;i<towerListProgress.Count;i++)
		{
			Towers tlp = towerListProgress[i];
			float t = (Time.time-tlp.lastBarTime)*progressBarSpeed;
			if(barsLookAtCamera)
			{
				tlp.upgradeBar.transform.LookAt(cam.transform.position);
				tlp.upgradeBarBack.transform.LookAt(cam.transform.position);
			}
			//if reached the end of the progression, get more power and disable rendering it
			if(t>=1f) 
			{
				tlp.firePower=tlp.nextFirePower;
				tlp.obj.GetComponent<TowersScript>().firePower=tlp.firePower;
				tlp.upgradeBar.renderer.enabled=false;
				tlp.upgradeBarBack.renderer.enabled=false;
				Color c = Color.Lerp(tlp.color,Color.cyan,tlp.firePower/5f);
				tlp.obj.renderer.material.color=c;
				tlp.actualColor=c;
				towerListProgress.Remove(tlp);
			}
			else 
			{
				Vector3 newScale = Vector3.Lerp(tlp.lastBarScale,tlp.newBarScale,t);
				tlp.upgradeBar.transform.localScale=newScale;
			}
		}
		if(enemiesList.Count>0)
		{
			for(int i=0;i<enemiesList.Count;i++)
			{
				//If the enemy is already killed continue
				if(enemiesList[i]==null) continue;
				Enemies e = enemiesList[i];
				//if we want that bars look at camera
				if(barsLookAtCamera)
				{
					e.healthBar.transform.LookAt(cam.transform.position);
					e.healthBarBack.transform.LookAt(cam.transform.position);
				}
			}
		}
		//No enemies, win!
		else 
		{
			Time.timeScale=0;
			gameWin=true;
		}
	}

	//Wait to execute after Update phase and dont do anything meanwhile every coroutine is executed
	IEnumerator processMove()
	{
		GameObject goQ = EneMovQueue[0];
		goQ.GetComponent<AIScript>().ready=true;
		goQ.GetComponent<AIScript>().dontMove=false;
		goQ.GetComponent<AIScript>().AIMethod();
		EneMovQueue.Remove(goQ);
		yield return null;
	}

	//To avoid bottleneck with simulatneous seek path calls when a new tower is placed
	void moveEneQueue()
	{
		if(EneMovQueue.Count>0) StartCoroutine(processMove());
	}
	
	void Update () {
		//Game starts when start button is clicked
		if(start) return;
		controlsCheck();
		barsCheck();
		moveEneQueue();
	}
}


