﻿// Diego Pena Gayo 2014

using UnityEngine;
using System.Collections;

public class BallScript : MonoBehaviour {

	[HideInInspector]
	public float damage;
	[HideInInspector]
	public Enemies enemy;
	[HideInInspector]
	public Vector3 direction;

	public float movSpeed=20f;
	
	void Start () {
		renderer.material.color=new Color(1f,0.75f,0,1f);
		//Place it in front of the tower so that doesnt collide with it and be destroyed with its own tower
		transform.Translate(direction*GameManager.Instance.cubeSize);
		//Destroy after 10 seconds so that balls dont stay forever in case of not colliding
		Destroy(gameObject,10f);
	}

	void Update()
	{
		transform.position+=direction*Time.deltaTime*movSpeed;
	}

	void OnTriggerEnter(Collider col)
	{
		//If enemy
		if(col.gameObject.layer==10)
		{
			if(enemy.obj!=null)
			{
				Vector3 le = enemy.healthBarBack.transform.localScale;
				enemy.life-=damage;
				float life = (le.x*enemy.life)/enemy.maxLife;
				if(life<=0) 
				{
					GameManager.Instance.enemiesList.Remove(enemy);
					GameManager.Instance.EneMovQueue.Remove(enemy.obj);
					Destroy(enemy.obj);
					GameManager.Instance.money+=100*enemy.level;
				}
				else enemy.healthBar.transform.localScale=new Vector3(life,le.y,le.z);
			}
			Destroy(gameObject);
		}
		// vs towers, crystals or other balls 
		else if(col.gameObject.layer==9 || col.gameObject.layer==11 || col.gameObject.layer==13) Destroy(gameObject);
	}
}
