﻿using UnityEngine;
using System.Collections;

public class CrystalTarget : MonoBehaviour {

	Vector3 prevPos = Vector3.zero;
	public delegate void HandlerEvent();
	public event HandlerEvent OnMove = new HandlerEvent(()=>{});

	void Awake () {
		prevPos = transform.position;
	}
	
	void Update () {
		if(prevPos != transform.position){
			OnMove();
			prevPos = transform.position;
		}
	}
}
