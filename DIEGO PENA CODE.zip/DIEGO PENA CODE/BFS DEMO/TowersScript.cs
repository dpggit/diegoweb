﻿// Diego Pena Gayo 2014

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum towerType{onexone,onextwo}

public class TowersScript : MonoBehaviour {

	public float ballFireRate=2f;
	public float rotationSpeed=1f;
	public float firePower=1f;
	public float damageSpeed=0.05f;
	public bool makeRotate=false;
	//How fast firePower is applied
	public towerType TowerT;
	public GameObject ball;

	
	float findNext;
	float fireNext;
	float dist;
	float lastTimeRot;

	int id;

	Vector3 direction;

	LineRenderer lineR;
	RaycastHit hit;
	Enemies cloE;

	void Awake () {
		id=gameObject.GetInstanceID();
		findNext=ballFireRate;
		if(TowerT==towerType.onexone) 
		{
			findEnemy();
			direction = cloE.obj.transform.position-transform.position;
			if(makeRotate) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), 20f * Time.deltaTime);
		}
		else lineR=GetComponent<LineRenderer>();
	}

	//Find closest enemy to the tower
	Enemies findClosestEnemy()
	{
		float distance = float.PositiveInfinity;
		Enemies target = null;
		for(int i = 0; i < GameManager.Instance.enemiesList.Count; i++)
		{
			float dist = (transform.position - GameManager.Instance.enemiesList[i].obj.transform.position).sqrMagnitude;
			if(dist <= distance)
			{
				distance = dist;
				target = GameManager.Instance.enemiesList[i];
			}
		}
		if(GameManager.Instance.enemiesList.Count==0) return null;
		else return target;
	}

	void laserAttack(Vector3 enepos)
	{
		Vector3 posOri=transform.position-new Vector3(0,0,GameManager.Instance.halfCubeSize);
		//If hit with anything that is not the own tower or an enemy dont continue
		Vector3 dir = enepos-posOri;
		RaycastHit[] cols =  Physics.SphereCastAll(posOri,0.2f,dir,dir.magnitude);
		for(int i=0;i<cols.Length;i++)
		{
			GameObject colGO = cols[i].collider.gameObject;
			if(colGO.layer!=10)
			{
				if(colGO.GetInstanceID()!=id)
				{
					lineR.enabled=false;
					return;
				}
			}
		}
		lineR.enabled=true;
		lineR.SetPosition(0,posOri);
		lineR.SetPosition(1,enepos);
		Vector3 le = cloE.healthBarBack.transform.localScale;
		float damage = firePower*Time.deltaTime*damageSpeed;
		cloE.life-=damage;
		float life = (le.x*cloE.life)/cloE.maxLife;
		if(life<=0) 
		{
			lineR.SetPosition(1,posOri);
			GameManager.Instance.enemiesList.Remove(cloE);
			GameManager.Instance.EneMovQueue.Remove(cloE.obj);
			Destroy(cloE.obj);
			GameManager.Instance.money+=100*cloE.level;
		}
		else cloE.healthBar.transform.localScale=new Vector3(life,le.y,le.z);
	}

	void ballAttCheck()
	{
		if(makeRotate) lastTimeRot=Time.time;
		else ballAttack();
	}

	void ballAttack()
	{
		GameObject goBall = Instantiate(ball,transform.position,Quaternion.identity) as GameObject;
		goBall.transform.localScale*=GameManager.Instance.halfCubeSize;
		goBall.GetComponent<BallScript>().damage=firePower;
		goBall.GetComponent<BallScript>().enemy=cloE;
		goBall.GetComponent<BallScript>().direction=direction.normalized;
	}

	void findEnemy()
	{
		cloE = findClosestEnemy();
		//No enemy in range
		if(cloE==null) return;
		Vector3 enepos = cloE.obj.transform.position;
		dist = (enepos-transform.position).sqrMagnitude;
		if(dist<GameManager.Instance.fireRange) 
		{
			if(TowerT==towerType.onextwo) laserAttack(enepos);
			else ballAttCheck();
		}
		else if(TowerT==towerType.onextwo)
		{
			lineR.enabled=false;
		}
	}

	void Update () {
		if(TowerT==towerType.onexone)
		{
			if(Time.time>=findNext)
			{
				findNext=Time.time+ballFireRate;
				findEnemy();
			}
			if(cloE!=null)
			{
				if(cloE.obj!=null)
				{
					direction = cloE.obj.transform.position-transform.position;
					//In case we want towers to rotate
					if(makeRotate)
					{
						float t=(Time.time-lastTimeRot)*rotationSpeed;
						transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.LookRotation(direction), t);
						//Wait until rotation is made or wont hit in target sometimes
						if(t>=1)
						{
							if(Time.time>=fireNext)
							{
								fireNext=Time.time+ballFireRate;
								ballAttack();
							}
						}
					}
				}
			}
		}
		else findEnemy();
	}
}
