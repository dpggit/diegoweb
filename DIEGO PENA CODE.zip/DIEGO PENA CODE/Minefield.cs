﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace ConsoleApp1
{
    public enum Cell
    {
        EMPTY,
        M1,
        M2,
        M3,
        M4,
        M5,
        M6,
        M7,
        M8,
        M9,
        MINE,
        CLOSED
    };

    public class Minefield
    {
        static int cellsLength;
        static Random random;
        static List<CellValue> Cells = new List<CellValue>();
        static int TotalCells;

        static void Main(string[] args)
        {
            uint arg1, arg2, arg3, arg4;
            string swidth="", sheight="", sminesnumber="", sminechance = "";
            Console.WriteLine("Mine game");
            Console.WriteLine("Please enter the width : ");
            swidth = Console.ReadLine();
            while (swidth == "" || !uint.TryParse(swidth, out arg1))
            {
                Console.WriteLine("Please enter the width : ");
                swidth = Console.ReadLine();
            }
            Console.WriteLine("Please enter the height : ");
            sheight = Console.ReadLine();
            while (sheight == "" || !uint.TryParse(sheight, out arg2))
            {
                Console.WriteLine("Please enter the height : ");
                sheight = Console.ReadLine();
            }
            Console.WriteLine("Please enter the maximum number of mines : ");
            sminesnumber = Console.ReadLine();
            while (sminesnumber == "" || !uint.TryParse(sminesnumber, out arg3))
            {
                Console.WriteLine("Please enter the maximum number of mines : ");
                sminesnumber = Console.ReadLine();
            }
            Console.WriteLine("Please enter the chance of having a mine from 1 to 10 : ");
            sminechance = Console.ReadLine();
            uint.TryParse(sminechance, out arg4);
            while (sminechance == "" || !uint.TryParse(sminechance, out arg4) || arg4 < 1 || arg4 > 10)
            {
                Console.WriteLine("Please enter the chance of having a mine from 1 to 10 : ");
                sminechance = Console.ReadLine();
            }
            GenerateMineField(arg1, arg2, arg3, arg4);
        }

        //Create the mines and detect the mines for the neighbours
        private static void GenerateMineField(uint width, uint height, uint count, uint chance)
        {
            TotalCells = (int)(width * height);
            uint mineNumber=0;
            for (int i=0;i < TotalCells; i++)
            {
                Cells.Add(new CellValue(Cell.EMPTY,0));
            }
            int[] cellValues = new int[12];
            cellsLength = Cells.Count-1;
            int m1, m2, m3, m4, m5, m6, m7, m8;
            int seed;
            for (int i=0;i< TotalCells; i++)
            {
                m1 = i - (int)width - 1;
                m2 = i - (int)width;
                m3 = i - (int)width + 1;
                m4 = i - 1;
                m5 = i + 1;
                m6 = i + (int)width - 1;
                m7 = i + (int)width;
                m8 = i + (int)width + 1;
                //Create a true random value
                seed = Convert.ToInt32(Regex.Match(Guid.NewGuid().ToString(), @"\d+").Value);
                random = new Random(seed);
                if (random.Next(1,11) <= chance && mineNumber < count)
                {
                    mineNumber++;
                    Cells[i].CellType = Cell.MINE;
                    if (IsInRange(m1,i, width, true, false)) Cells[m1].MinesDetected++;
                    if (IsInRange(m2,i, width, false, false)) Cells[m2].MinesDetected++;
                    if (IsInRange(m3,i, width, false, true)) Cells[m3].MinesDetected++;
                    if (IsInRange(m4,i, width, true, false)) Cells[m4].MinesDetected++;
                    if (IsInRange(m5,i, width, false, true)) Cells[m5].MinesDetected++;
                    if (IsInRange(m6,i, width, true, false)) Cells[m6].MinesDetected++;
                    if (IsInRange(m7,i, width, false, false)) Cells[m7].MinesDetected++;
                    if (IsInRange(m8,i, width, false, true)) Cells[m8].MinesDetected++;
                }              
            }
            //Show the values in screen
            for (int i = 0; i < TotalCells; i++)
            {
                if (i % width == 0) Console.WriteLine("");
                if (Cells[i].CellType == Cell.MINE) Console.Write("M");
                else if (Cells[i].MinesDetected > 0) Console.Write(Cells[i].MinesDetected);
                else Console.Write(".");
            }
        }

        //When increasing or decreasing the cellIndex must check if it is appropiate to do so
        static bool IsInRange(int cellIndex, int vi, uint width, bool canBeLeftColumn, bool canBeRightColumn)
        {
            if(canBeLeftColumn) return (cellIndex >= 0 && cellIndex < TotalCells && vi % width > 0) ? true : false;
            else if(canBeRightColumn) return (cellIndex >= 0 && cellIndex < TotalCells && (vi + 1) % width > 0) ? true : false;
            else return (cellIndex >= 0 && cellIndex < TotalCells) ? true : false;
        }
    }

    //Class for Cells
    public class CellValue
    {
        public Cell CellType = Cell.EMPTY;
        //The number of mines detected
        public sbyte MinesDetected; 
        public CellValue(Cell cellType, sbyte minesDetected)
        {
            this.CellType = cellType;
            this.MinesDetected = minesDetected;
        }
    }

}
